Template name: Renewal - Follow-up 4
Template ID: 991103000001486010
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Renewal cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 4.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact approaching renewal, late in the cadence. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Anything you need from me?

Body:
Hi ${!Contacts.First_Name},

Is there anything you need from me to finalise ${!Contacts.Account_Name.Account_Name}'s renewal? I'm happy to help it go smoothly. You can complete it here: ${!Contacts.Account_Name.Contract_Renewal_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: existing client, renewal pending. Copy offers help to complete; claims no decision.
Single call to action: complete via the link.
Divergence from live: unchanged. No em dash involved.
