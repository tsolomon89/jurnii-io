Template name: Commercial Agreement - Initial 1 - Warm
Template ID: 991103000002754001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "warm" (resolveOpenerVariant). Swaps only the template id for the commercial-agreement:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a familiar Contact at the Commercial Agreement stage; a proposal has been sent. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Following up on your ${!org.company_name} proposal

Body:
Hi ${!Contacts.First_Name},

Thanks again for the conversations so far. I'm keen to get things over the line for ${!Contacts.Account_Name.Account_Name}.

The proposal and terms are ready to review here: ${!Contacts.Account_Name.Contract_URL}. If everything looks right, I can talk you through next steps whenever suits, and if anything needs adjusting, tell me and I'll turn it around quickly.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live; contract link retained.
Warm semantics: familiar contact, direct push to close; "conversations so far" is safe because reaching Commercial Agreement plus the warm tag guarantees prior engagement, without citing a specific call.
Single call to action: review the proposal via the link. Live copy contained an em dash; removed.
