Template name: Marketing Consent - Follow-up 4
Template ID: 991103000001474007
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Marketing Consent cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 4.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the top of the funnel, late in the cadence. The email's job is marketing qualification: a shallow, category-level pitch. Sender is the Deal Owner.

Subject:
Worth a short conversation, ${!Contacts.First_Name}?

Body:
Hi ${!Contacts.First_Name},

I'll keep this brief. If understanding where ${!Contacts.Account_Name.Account_Name} stands against the market would help your team, fifteen minutes is usually enough to tell whether ${!org.company_name} is worth pursuing. If the timing isn't right, just say so and I'll leave it there.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.first_name}, ${!userSignature}. Preserved from live; none changed.
Reframed to a light qualification nudge with a clear opt-out. Category-level; no product or competitor named.
Guaranteed by trigger: still top of funnel. Copy makes the low-effort case for a short session.
Single call to action: a short conversation, with a graceful exit.
