Template name: Renewal - Follow-up 3
Template ID: 991103000001484004
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Renewal cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 3.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact approaching renewal, mid-cadence. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
A quick renewal check-in

Body:
Hi ${!Contacts.First_Name},

Checking in on ${!Contacts.Account_Name.Account_Name}'s renewal. If there's anything you'd like to discuss or adjust, I'm here. The renewal is ready whenever you are: ${!Contacts.Account_Name.Contract_Renewal_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: existing client, renewal pending. Copy is a light check-in with an open door to adjust.
Single call to action: review via the link.
Divergence from live: unchanged. No em dash involved.
