Template name: Commercial Agreement - Follow-up 2
Template ID: 991103000001469004
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Commercial Agreement cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 2.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Commercial Agreement stage; a proposal has been sent. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Happy to walk through the details

Body:
Hi ${!Contacts.First_Name},

Following up on the proposal for ${!Contacts.Account_Name.Account_Name}. If it helps, I can walk through any section or adjust the details so it works for your team. The documents are here: ${!Contacts.Account_Name.Contract_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: proposal sent, not yet signed. Copy offers to explain or adjust; claims no agreement.
Single call to action: review or reply for a walk-through.
Divergence from live: unchanged. No em dash involved.
