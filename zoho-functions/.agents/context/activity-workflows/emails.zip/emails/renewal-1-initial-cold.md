Template name: Renewal - Initial 1 - Cold
Template ID: 991103000002757001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "cold" (resolveOpenerVariant). Swaps only the template id for the renewal:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact who has gone quiet, approaching renewal. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Your ${!org.company_name} renewal

Body:
Hi ${!Contacts.First_Name},

${!Contacts.Account_Name.Account_Name}'s renewal with ${!org.company_name} is approaching, and I wanted to check in properly rather than let it pass by default.

The details are here whenever you'd like to look: ${!Contacts.Account_Name.Contract_Renewal_URL}. If the last stretch has been less useful than you hoped, or anything's changed on your side, I'd really like to hear it before the date so we can put it right or make the right call together.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Cold semantics: an existing client who has gone quiet. Copy invites an honest read on the last period and offers to put things right; it acknowledges possible dissatisfaction without asserting it as fact.
Single call to action: review the renewal via the link (with an open invitation to talk). Live copy contained an em dash; removed.
