Template name: Demo Confirmation - Confirmation
Template ID: 991103000001474010
Triggered by: automation.sendSequencedEmail (kind demo_confirmation), dispatched by routeContactSequence from the meeting:created branch when a demo Meeting or Event is booked (handleMeetingEvent).
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact who has just had a demo booked. Sender is the Deal Owner. Reschedule link ${!users.website}.

Subject:
Your ${!org.company_name} demo is confirmed

Body:
Hi ${!Contacts.First_Name},

Your demo for ${!Contacts.Account_Name.Account_Name} is confirmed and I'm looking forward to it. We'll keep it focused on what matters most to your team, so if there's anything specific you'd like us to cover, just reply and let me know.

If you need to change the time, you can do that here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live; reschedule link retained.
Guaranteed by trigger: a demo has been booked. Copy confirms it; makes no claim about outcome or product.
Transactional: kept minimal per the Balanced brief. Primary purpose is confirmation; the reschedule link is an operational aid, not a competing call to action.
Divergence from live: effectively unchanged. Live copy contained an em dash; removed.
