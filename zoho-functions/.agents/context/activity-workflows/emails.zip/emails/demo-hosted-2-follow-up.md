Template name: Demo Hosted - Follow-up 2
Template ID: 991103000001470002
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Hosted cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 2.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Hosted stage (demo not yet held). Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Still keen on a quick ${!org.company_name} demo?

Body:
Hi ${!Contacts.First_Name},

Following up: are you still interested in seeing ${!org.company_name} for ${!Contacts.Account_Name.Account_Name}? No concern if the timing wasn't right before.

Whenever you're ready, you can grab a slot that works for you here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: demo still outstanding. Copy asks whether interest remains and offers rebooking; does not claim a demo took place.
Live copy (updated 2026-06-25) is already missed-demo wording, diverging from the older manifest; draft follows live.
Single call to action: book via the link.
