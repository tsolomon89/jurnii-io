Template name: Marketing Consent - Initial 1
Template ID: 991103000001478002
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence. Sent when a rep completes the Contact's Sequence Activation Task (handleTaskCompletion, activate:email) with no warm/cold tag on the Activation Task note, and also as cadence step 1 for the Marketing Consent stage.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the top of the funnel. The internal stage name is Marketing Consent, but the email's job is marketing qualification: a shallow, category-level pitch that gauges interest. Consent is handled by the send gate, not by this email. Sender is the Deal Owner.

Subject:
Where ${!Contacts.Account_Name.Account_Name} stands against the market

Body:
Hi ${!Contacts.First_Name},

In a market where operators share the same games, suppliers and roadmaps, the customer experience is one of the few things left to compete on. Most teams still review how they compare quarterly, while the market moves daily.

${!org.company_name} gives operators a continuous, structured view of their own experience and their competitors', connected to conversion, churn and NGR rather than opinion. If a clearer picture of where ${!Contacts.Account_Name.Account_Name} stands would be useful, I'd welcome a short conversation.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.first_name}, ${!userSignature}. All preserved from the live template; none changed.
Reframed from a consent/permission ask to a shallow qualification pitch, per direction: the stage's operative goal is marketing qualification. The pitch stays at the intelligence-layer level (own experience plus competitors', tied to commercial outcomes); no product named (UX, 360, Cortex), no competitor named, no per-recipient figure.
Guaranteed by trigger: the Contact has just entered the top of the funnel. Nothing else is claimed (no prior call, meeting or product).
Single call to action: a short conversation to gauge fit.
"Near-real-time" deliberately avoided here (brand guide reserves it for Jurnii 360); used "continuous, structured, not quarterly" instead, which is product-agnostic.
