Template name: Commercial Agreement - Initial 1 - Cold
Template ID: 991103000002755001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "cold" (resolveOpenerVariant). Swaps only the template id for the commercial-agreement:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a Contact who has gone quiet at the Commercial Agreement stage; a proposal has been sent. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Following up on your ${!org.company_name} proposal

Body:
Hi ${!Contacts.First_Name},

I wanted to leave the door open on the ${!org.company_name} proposal for ${!Contacts.Account_Name.Account_Name}, in case it slipped down the list. Completely understandable if so.

Whenever you have a moment, the terms are here to review at your own pace: ${!Contacts.Account_Name.Contract_URL}. If there's a question, a concern, or a reason the timing isn't right, I'd genuinely welcome the honest version. No pressure either way.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Cold semantics: a contact who went quiet after a proposal was sent. Copy reopens gently and invites an honest steer; claims no agreement and no specific prior call.
Single call to action: review the proposal via the link. Live copy contained an em dash; removed.
