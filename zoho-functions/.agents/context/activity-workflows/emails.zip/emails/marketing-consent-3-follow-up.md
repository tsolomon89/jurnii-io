Template name: Marketing Consent - Follow-up 3
Template ID: 991103000001484001
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Marketing Consent cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 3.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the top of the funnel, after further touches that did not connect. The email's job is marketing qualification: a shallow, category-level pitch. Sender is the Deal Owner.

Subject:
A clearer read on ${!Contacts.Account_Name.Account_Name}'s experience

Body:
Hi ${!Contacts.First_Name},

Checking in. Most views of customer experience come down to opinion. ${!org.company_name} replaces that with a structured read of how ${!Contacts.Account_Name.Account_Name} compares to the market, and where that's costing or earning you commercially.

If a short conversation would be useful, I'll keep it to the parts that matter to you.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live; none changed.
Reframed to a shallow qualification pitch on the objectivity angle (evidence over opinion), a core brand trait. Category-level; no product or competitor named.
Guaranteed by trigger: still top of funnel, no decision. Copy offers a focused conversation.
Single call to action: a short conversation.
