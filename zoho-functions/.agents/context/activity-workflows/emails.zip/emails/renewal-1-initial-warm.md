Template name: Renewal - Initial 1 - Warm
Template ID: 991103000002756001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "warm" (resolveOpenerVariant). Swaps only the template id for the renewal:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact, well engaged, approaching renewal. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Your ${!org.company_name} renewal

Body:
Hi ${!Contacts.First_Name},

It's been good having ${!Contacts.Account_Name.Account_Name} with ${!org.company_name}, and your renewal is coming up. I'd like to make it as smooth as possible.

You can review everything here: ${!Contacts.Account_Name.Contract_Renewal_URL}. If it all looks good I'll take care of the rest, and if you'd like to revisit anything first, just say the word.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live; renewal link retained.
Warm semantics: an engaged client; the copy is warm and low-effort. "It's been good having you" is safe (renewal implies an existing agreement) and claims no specific usage or result.
Single call to action: review the renewal via the link. No em dash in live for this one; none added.
