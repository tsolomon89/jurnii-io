Template name: Demo Booking - Follow-up 4
Template ID: 991103000001487001
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Booking cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 4.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Booking stage, late in the cadence. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Worth a quick look, ${!Contacts.First_Name}?

Body:
Hi ${!Contacts.First_Name},

I'll keep this brief. If a short demo would help ${!Contacts.Account_Name.Account_Name} reach a clear yes or no, I'd be glad to set it up: ${!users.website}. If the timing's off, tell me and I'll follow up later instead.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: still booking. Copy frames the demo as a way to decide either way, with a graceful exit.
Single call to action: book via the link.
Divergence from live: effectively unchanged. No em dash involved.
