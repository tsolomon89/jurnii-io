Template name: Demo Hosted - Initial 1 - Cold
Template ID: 991103000002749005
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "cold" (resolveOpenerVariant). Swaps only the template id for the demo-hosted:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a Contact who went quiet at the Demo Hosted stage. As with the base demo-hosted opener, this is demo recovery: a demo was scheduled but did not take place. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Let's find another time for your ${!org.company_name} demo

Body:
Hi ${!Contacts.First_Name},

We had a ${!org.company_name} demo pencilled in a while back but didn't get the chance to connect. Entirely understandable if the timing slipped or priorities moved on.

No pressure either way: if a look at what we could do for ${!Contacts.Account_Name.Account_Name} is still useful, a new time is here whenever you're ready: ${!users.website}. If now isn't right, let me know and I'll follow your lead.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Cold semantics on a missed demo: a contact who went quiet after a demo was pencilled in. Copy reconnects and offers rebooking; does NOT claim the demo happened.
Single call to action: reschedule via the link, with a clean exit. Live copy contained an em dash; removed.
