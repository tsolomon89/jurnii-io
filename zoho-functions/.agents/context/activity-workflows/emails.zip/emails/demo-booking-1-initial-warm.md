Template name: Demo Booking - Initial 1 - Warm
Template ID: 991103000002751001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "warm" (resolveOpenerVariant). Swaps only the template id for the demo-booking:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a familiar Contact entering the Demo Booking stage. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
A short walkthrough for ${!Contacts.Account_Name.Account_Name}?

Body:
Hi ${!Contacts.First_Name},

Following the interest you've shown in ${!org.company_name}, I'd like to get a proper walkthrough in the diary for ${!Contacts.Account_Name.Account_Name}, tailored to the outcomes you care about rather than a generic tour.

Grab whatever time works best here: ${!users.website}. If none of those slots fit, reply with a couple of windows and I'll make one work.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live; booking link retained.
Warm semantics: familiar contact, direct move to book; references prior interest (guaranteed by the tag), no specific call.
Single call to action: book via the link. No em dash in live for this one; none added.
