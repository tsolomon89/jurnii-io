Template name: Demo Booking - Follow-up 3
Template ID: 991103000001486001
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Booking cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 3.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Booking stage, mid-cadence. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
I'll tailor it to ${!Contacts.Account_Name.Account_Name}

Body:
Hi ${!Contacts.First_Name},

Checking in. I can shape the walkthrough entirely around ${!Contacts.Account_Name.Account_Name}'s priorities, so it's time well spent rather than a standard demo. Let me know what you'd most want to see, or pick a slot here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: still booking. Copy offers personalisation of the session; claims nothing about a prior call.
Single call to action: reply with priorities or book via the link (one combined next step, not competing asks).
Divergence from live: unchanged in intent. No em dash involved.
