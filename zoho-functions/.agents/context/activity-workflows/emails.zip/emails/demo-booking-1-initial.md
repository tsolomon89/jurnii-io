Template name: Demo Booking - Initial 1
Template ID: 991103000001476004
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence. Sent on Sequence Activation with no warm/cold tag (handleTaskCompletion, activate:*), and as cadence step 1 for the Demo Booking stage.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Booking stage. Sender is the Deal Owner. Booking link comes from ${!users.website}.

Subject:
A short walkthrough for ${!Contacts.Account_Name.Account_Name}?

Body:
Hi ${!Contacts.First_Name},

I'd like to offer ${!Contacts.Account_Name.Account_Name} a brief, tailored walkthrough of ${!org.company_name}, focused on where you stand against your competitive set and what that's worth commercially, not a generic tour.

Fifteen minutes is usually enough to tell whether it's worth pursuing. You can pick a time that suits you here: ${!users.website}. If you'd rather I work around a specific window, just reply.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live; booking link ${!users.website} retained.
Guaranteed by trigger: Contact is at the Demo Booking stage; a demo is being offered, not yet booked. Copy offers, never assumes attendance.
"Where you stand against your competitive set" is a category-level benefit; no product named, no number claimed.
Single call to action: book a slot via the link.
Divergence from live: added a light commercial framing to the walkthrough offer. No em dash involved.
