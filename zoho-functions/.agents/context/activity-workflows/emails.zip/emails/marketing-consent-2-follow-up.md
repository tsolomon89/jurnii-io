Template name: Marketing Consent - Follow-up 2
Template ID: 991103000001467002
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Marketing Consent cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 2.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the top of the funnel, after a prior touch that did not connect. The email's job is marketing qualification: a shallow, category-level pitch. Sender is the Deal Owner.

Subject:
The market moves faster than the quarterly review

Body:
Hi ${!Contacts.First_Name},

Following up on my note. The gap most operators feel is speed: competitor promotions and journey changes shift week to week, but the benchmark they measure against is usually months old.

That's the gap ${!org.company_name} closes for teams like ${!Contacts.Account_Name.Account_Name}. If it's worth exploring, a short conversation is the quickest way to tell.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live; none changed.
Reframed to a shallow qualification pitch on the speed angle (market moves daily, benchmarks lag). Category-level; no product or competitor named, no number claimed.
Guaranteed by trigger: a prior touch happened but did not connect. Copy says "following up on my note" and never claims a call took place.
Single call to action: a short conversation.
