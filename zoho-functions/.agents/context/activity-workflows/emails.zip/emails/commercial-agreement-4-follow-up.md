Template name: Commercial Agreement - Follow-up 4
Template ID: 991103000001483002
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Commercial Agreement cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 4.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Commercial Agreement stage; a proposal has been sent, late in the cadence. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Anything outstanding on the proposal?

Body:
Hi ${!Contacts.First_Name},

Checking whether anything is holding things up on the proposal for ${!Contacts.Account_Name.Account_Name}. I'm happy to resolve any final questions so it's an easy yes or no. You can review it here: ${!Contacts.Account_Name.Contract_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: proposal sent, undecided. Copy invites a clear decision either way.
Single call to action: review via the link.
Divergence from live: unchanged. No em dash involved.
