Template name: Renewal - Final 5
Template ID: 991103000001484007
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as cadence step 5 (final), or as the scheduled post-call email (sendScheduledEmailFromTask) once call attempts are exhausted.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact approaching renewal, end of the cadence. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Final note on your renewal

Body:
Hi ${!Contacts.First_Name},

A last note on ${!Contacts.Account_Name.Account_Name}'s renewal so it doesn't slip by. Whenever you're ready, it's all here: ${!Contacts.Account_Name.Contract_Renewal_URL}, and a quick reply means I'll make sure it's handled.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: existing client, renewal pending at cadence end. Copy makes a final, low-pressure prompt so the renewal is not missed by default.
Single call to action: complete via the link or reply.
Divergence from live: unchanged. No em dash involved.
