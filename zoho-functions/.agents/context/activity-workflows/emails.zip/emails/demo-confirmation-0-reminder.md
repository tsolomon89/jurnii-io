Template name: Demo Confirmation - Reminder
Template ID: 991103000001487004
Triggered by: automation.sendDemoReminder (WF010c, date-based on Deal.Demo_Reminder_Send_At), which calls automation.sendSequencedEmail (kind demo_reminder). Gated on Automation_Suppressed != true, an upcoming Demo_Start_DateTime, and the Primary Contact being Open and not past Demo Confirmation.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact with a confirmed, upcoming demo. Sender is the Deal Owner. Reschedule link ${!users.website}.

Subject:
Reminder: your ${!org.company_name} demo is coming up

Body:
Hi ${!Contacts.First_Name},

A quick reminder about your upcoming demo for ${!Contacts.Account_Name.Account_Name}. I'm looking forward to walking you through it.

If anything has changed and you need to move the time, you can reschedule here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: an upcoming demo exists (the sender re-checks Demo_Start_DateTime is still in the future). Copy reminds only.
Transactional: kept minimal. Single purpose (reminder); reschedule link is operational.
Divergence from live: unchanged. No em dash involved.
