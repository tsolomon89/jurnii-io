Template name: Demo Hosted - Follow-up 4
Template ID: 991103000001471007
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Hosted cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 4.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Hosted stage (demo not yet held), late in the cadence. Sender is the Deal Owner.

Subject:
Where would you like to take this?

Body:
Hi ${!Contacts.First_Name},

A quick check-in. Is there anything I can clarify or line up to help ${!Contacts.Account_Name.Account_Name} decide whether a look at ${!org.company_name} is worthwhile? If it's a no for now, that's genuinely fine. Just let me know.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.first_name}, ${!userSignature}. Preserved from live (no booking link present live; reply-based).
Guaranteed by trigger: demo still outstanding. Copy offers to remove blockers to a decision; does not claim attendance.
Single call to action: reply either way.
Divergence from live: reworded so "reach a decision" is explicitly about whether to see the product, not a post-demo decision. Live copy contained an em dash; removed.
