Template name: Marketing Consent - Initial 1 - Warm
Template ID: 991103000002749002
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "warm" (resolveOpenerVariant, via handleTaskCompletion). Swaps only the template id for the marketing-consent:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a Contact the team already has a familiar relationship with, at the top of the funnel. The email's job is marketing qualification: a shallow, category-level pitch. Sender is the Deal Owner.

Subject:
Where ${!Contacts.Account_Name.Account_Name} stands against the market

Body:
Hi ${!Contacts.First_Name},

Good to be in touch properly. Given the interest you've already shown in ${!org.company_name}, I'll get to the point: we give operators a continuous, structured view of their own experience and their competitors', connected to conversion, churn and NGR rather than opinion.

If seeing where ${!Contacts.Account_Name.Account_Name} stands against the market would be useful, I'd welcome a short conversation.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Reframed from a consent ask to a shallow qualification pitch. Warm semantics (per user): the contact is already familiar, so the copy is direct and references prior interest, which the "warm" tag guarantees; it never references a specific prior call.
Category-level; no product or competitor named.
Single call to action: a short conversation.
