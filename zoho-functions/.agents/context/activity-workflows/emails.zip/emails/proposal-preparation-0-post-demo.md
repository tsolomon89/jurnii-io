Template name: Proposal Preparation - Post-Demo
Template ID: 991103000001484010
Triggered by: automation.sendSequencedEmail (kind demo_post_demo), dispatched by routeContactSequence from the demo:qualified branch after a demo is attended and qualified (handleMeetingEvent).
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact who attended a demo. Sender is the Deal Owner.

Subject:
Thanks for your time, here's what happens next

Body:
Hi ${!Contacts.First_Name},

Thank you for the demo. It was good to walk through ${!org.company_name} with you. Based on what we covered, the next step is to put together a proposal tailored to ${!Contacts.Account_Name.Account_Name}.

I'll be in touch shortly with the details. In the meantime, if any questions have come up, just reply.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: the demo was attended and qualified. This is the only template that may acknowledge the demo happened, and it does so without inventing what was discussed ("based on what we covered" stays general).
No manufactured call to action: the next action is Jurnii's (send the proposal). The reply option is a soft aid only.
Divergence from live: unchanged except the subject, where a hyphen dash was replaced with a comma. Body contained an em dash; removed.
