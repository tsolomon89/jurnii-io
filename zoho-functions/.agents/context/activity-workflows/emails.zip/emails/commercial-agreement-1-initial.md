Template name: Commercial Agreement - Initial 1
Template ID: 991103000001480002
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence on the commercial:sent entry, and as cadence step 1 for the Commercial Agreement stage. Also re-engaged by sendCommercialFollowUp (WF010d) while a Quote is still in flight.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Commercial Agreement stage; a proposal has been sent. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Following up on your ${!org.company_name} proposal

Body:
Hi ${!Contacts.First_Name},

Following up on the proposal for ${!Contacts.Account_Name.Account_Name} to see whether any questions have come up on the terms.

You can review everything here when convenient: ${!Contacts.Account_Name.Contract_URL}. I'm glad to talk through any part of it.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live; contract link retained.
Guaranteed by trigger: a proposal was sent. Copy states this and nothing further (no agreement, no start date).
Single call to action: review the proposal via the link.
Divergence from live: effectively unchanged. No em dash involved.
