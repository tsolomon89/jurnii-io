Template name: Demo Hosted - Final 5
Template ID: 991103000001488001
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as cadence step 5 (final), or as the scheduled post-call email (sendScheduledEmailFromTask) once call attempts are exhausted.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Hosted stage (demo not yet held), end of the cadence. Sender is the Deal Owner.

Subject:
I'll pause here for now

Body:
Hi ${!Contacts.First_Name},

I don't want to keep chasing, so I'll leave this with you. Whenever you're ready to pick up a walkthrough for ${!Contacts.Account_Name.Account_Name}, just reply and I'll get it straight back in the diary.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: cadence ending, demo still not held. Copy closes gracefully and keeps rebooking open.
Single call to action: reply when ready.
Divergence from live: reframed "revisit next steps" to "pick up a walkthrough" so it stays a demo-to-be-held close, consistent with the family.
