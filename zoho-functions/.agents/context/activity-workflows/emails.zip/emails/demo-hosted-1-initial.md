Template name: Demo Hosted - Initial 1
Template ID: 991103000001476007
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence on the Demo Hosted recovery entry (demo:followup, from handleMeetingEvent), and as cadence step 1 for the Demo Hosted stage.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Hosted stage. Despite the stage name, the live copy and trigger are demo recovery: a demo was scheduled but did not take place. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Let's find another time for your ${!org.company_name} demo

Body:
Hi ${!Contacts.First_Name},

We had a demo in the diary but didn't manage to connect. No problem at all, schedules shift.

I'd still like to walk ${!Contacts.Account_Name.Account_Name} through it and show you where you stand against your competitive set. Whenever it suits, you can pick a new time here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live; booking link retained.
IMPORTANT: this template does NOT claim the demo happened. Live copy (updated 2026-06-25, per docs/v6/V6_EMAIL_COPY_VERIFICATION.md) is a missed-demo reschedule, which diverges from the older EMAIL_MANIFEST.md wording ("Next steps after your demo"). The draft follows the live intent. Do not reintroduce attendance language.
Category-level benefit added ("where you stand against your competitive set"); no product named.
Single call to action: reschedule via the link. Live copy contained an em dash; removed.
