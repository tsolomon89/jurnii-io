Template name: Demo Booking - Initial 1 - Cold
Template ID: 991103000002752001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "cold" (resolveOpenerVariant). Swaps only the template id for the demo-booking:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a Contact who engaged before and went quiet, now at the Demo Booking stage. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
A short walkthrough for ${!Contacts.Account_Name.Account_Name}?

Body:
Hi ${!Contacts.First_Name},

It's been quiet between us for a bit, so rather than a long email I'll keep it simple: the offer of a short, no-obligation look at ${!org.company_name} for ${!Contacts.Account_Name.Account_Name} still stands, around twenty minutes focused only on what's relevant to your team.

If that's worthwhile, pick any time that suits here: ${!users.website}. If you'd first like a sense of whether it's a fit, just reply.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Cold semantics: a contact who went quiet, not a new lead. Copy reconnects ("it's been quiet between us"), which the tag guarantees, without referencing a specific prior call.
Single call to action: book via the link, or reply for a quick fit check.
Divergence from live: reframed the live "I don't think we've spoken yet" (new-lead framing) into a reconnection after going quiet, matching the intended cold meaning. Live copy contained an em dash; removed.
