Template name: Renewal - Initial 1
Template ID: 991103000001486007
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence. Sent on Sequence Activation with no warm/cold tag (handleTaskCompletion, activate:*), and as cadence step 1 for the Renewal stage.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact whose term is approaching renewal. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Your ${!org.company_name} renewal

Body:
Hi ${!Contacts.First_Name},

Reaching out ahead of ${!Contacts.Account_Name.Account_Name}'s renewal to make sure everything's set and to answer any questions before it comes around.

You can review the renewal here: ${!Contacts.Account_Name.Contract_Renewal_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live; renewal link retained.
Guaranteed by trigger: an existing client whose renewal is approaching. Copy assumes the relationship (safe: renewal implies an existing agreement) but claims no specific usage or outcome.
Single call to action: review the renewal via the link.
Divergence from live: effectively unchanged. No em dash involved.
