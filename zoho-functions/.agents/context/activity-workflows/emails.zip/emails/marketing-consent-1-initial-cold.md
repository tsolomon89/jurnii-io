Template name: Marketing Consent - Initial 1 - Cold
Template ID: 991103000002750001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "cold" (resolveOpenerVariant, via handleTaskCompletion). Swaps only the template id for the marketing-consent:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a Contact who engaged before and then went quiet (a cooled contact, not a brand-new lead), re-entering the top of the funnel. The email's job is marketing qualification: a shallow, category-level pitch. Sender is the Deal Owner.

Subject:
Where ${!Contacts.Account_Name.Account_Name} stands against the market

Body:
Hi ${!Contacts.First_Name},

It's been a little while since we were last in touch, so I wanted to reconnect. In case it's useful now: ${!org.company_name} gives operators a continuous, structured view of their own experience and their competitors', connected to conversion, churn and NGR rather than opinion.

If a clearer picture of where ${!Contacts.Account_Name.Account_Name} stands would help, I'd welcome a short conversation. If not, just say so and I'll leave it there.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Reframed from a new-lead consent ask to a shallow qualification pitch. Cold semantics (per user): "cold" means a contact who dropped off, not a new lead, so the copy reconnects after a quiet period (guaranteed by the tag) without referencing any specific prior call.
Category-level; no product or competitor named.
Single call to action: a short conversation, with a clean exit.
