Template name: Commercial Agreement - Proposal and Terms
Template ID: 991103000001475003
Triggered by: automation.sendSequencedEmail (kind commercials_terms), dispatched by routeContactSequence from the commercial:sent branch. Upstream, a rep completes the "Send Commercials" Task (handleTaskCompletion), which delivers the Quotes and routes commercial:sent via processDeal.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact who has just been sent a proposal and terms. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Your ${!org.company_name} proposal and terms

Body:
Hi ${!Contacts.First_Name},

Please find the proposal and terms prepared for ${!Contacts.Account_Name.Account_Name}. You can review and complete everything here: ${!Contacts.Account_Name.Contract_URL}.

I'm happy to walk through any detail. Just reply and we'll find a time.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live; contract link retained.
Guaranteed by trigger: proposal and terms have been sent. Copy delivers them and offers a walk-through.
Transactional: kept minimal. Single purpose (deliver and invite review) via the link.
Divergence from live: unchanged; subject already matched intent. Body contained an em dash; removed.
