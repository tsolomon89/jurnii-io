Template name: Renewal - Follow-up 2
Template ID: 991103000001489001
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Renewal cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 2.
Pipeline context: B2B pipeline only. Recipient is an existing client Contact approaching renewal. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_Renewal_URL}.

Subject:
Reviewing ${!Contacts.Account_Name.Account_Name}'s renewal

Body:
Hi ${!Contacts.First_Name},

Following up on the renewal. I'm glad to review how things are going and the options available so it continues to fit ${!Contacts.Account_Name.Account_Name}. Details here: ${!Contacts.Account_Name.Contract_Renewal_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_Renewal_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: existing client, renewal pending. Copy offers a review of options; claims no particular result.
Single call to action: review via the link.
Divergence from live: unchanged. No em dash involved.
