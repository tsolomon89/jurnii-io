Template name: Demo Hosted - Initial 1 - Warm
Template ID: 991103000002753001
Triggered by: automation.sendSequencedEmail (kind opener), dispatched by routeContactSequence on Sequence Activation when the Activation Task's latest Note reads exactly "warm" (resolveOpenerVariant). Swaps only the template id for the demo-hosted:1:initial opener.
Pipeline context: B2B pipeline only. Recipient is a familiar Contact at the Demo Hosted stage. As with the base demo-hosted opener, this is demo recovery: a demo was scheduled but did not take place. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Let's find another time for your ${!org.company_name} demo

Body:
Hi ${!Contacts.First_Name},

We had time set aside for your ${!org.company_name} demo but didn't manage to connect. No problem at all, these things happen.

I'd still like to walk ${!Contacts.Account_Name.Account_Name} through it properly and pick up right where we left off. Choose whatever suits you here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Warm semantics on a missed demo: familiar contact, direct reschedule. Does NOT claim the demo happened.
Single call to action: reschedule via the link. Live copy contained an em dash; removed.
