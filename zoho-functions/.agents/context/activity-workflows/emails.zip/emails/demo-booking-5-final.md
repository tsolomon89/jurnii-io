Template name: Demo Booking - Final 5
Template ID: 991103000001478008
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as cadence step 5 (final), or as the scheduled post-call email (sendScheduledEmailFromTask) once call attempts are exhausted.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Booking stage, end of the cadence. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
Closing the loop on a demo

Body:
Hi ${!Contacts.First_Name},

I'll leave this here for now so I'm not chasing. Whenever a walkthrough for ${!Contacts.Account_Name.Account_Name} would be useful, the link stays open: ${!users.website}. Thanks for your time, ${!Contacts.First_Name}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: cadence ending, no demo booked. Copy closes gracefully and keeps the link available.
Single call to action: book whenever ready.
Divergence from live: unchanged. No em dash involved.
