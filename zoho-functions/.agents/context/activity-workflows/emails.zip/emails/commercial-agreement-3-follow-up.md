Template name: Commercial Agreement - Follow-up 3
Template ID: 991103000001486004
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Commercial Agreement cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 3.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Commercial Agreement stage; a proposal has been sent. Sender is the Deal Owner. Review link ${!Contacts.Account_Name.Contract_URL}.

Subject:
Aligning on timing for ${!Contacts.Account_Name.Account_Name}

Body:
Hi ${!Contacts.First_Name},

Checking in on timing. If it's useful to align on a target start date for ${!Contacts.Account_Name.Account_Name}, I'm glad to coordinate around what works for you. The proposal remains here: ${!Contacts.Account_Name.Contract_URL}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!Contacts.Account_Name.Contract_URL}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: proposal sent, not signed. "Target start date" is conditional ("if it's useful"), so it does not assume the deal is agreed.
Single call to action: review or reply on timing.
Divergence from live: unchanged. No em dash involved.
