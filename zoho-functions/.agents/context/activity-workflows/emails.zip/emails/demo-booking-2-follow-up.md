Template name: Demo Booking - Follow-up 2
Template ID: 991103000001478005
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Booking cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 2.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Booking stage, after a prior touch that did not connect. Sender is the Deal Owner. Booking link ${!users.website}.

Subject:
15 minutes to see if it fits?

Body:
Hi ${!Contacts.First_Name},

Following up on a walkthrough. A focused fifteen minutes is usually enough to tell whether ${!org.company_name} is worth pursuing for ${!Contacts.Account_Name.Account_Name}, with no preparation needed on your side.

Grab whatever time works: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!org.company_name}, ${!Contacts.Account_Name.Account_Name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: still booking; no demo has happened. Copy makes the low-effort case for a short session.
Single call to action: book via the link.
Divergence from live: effectively unchanged. No em dash involved.
