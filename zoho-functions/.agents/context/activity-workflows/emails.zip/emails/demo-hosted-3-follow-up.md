Template name: Demo Hosted - Follow-up 3
Template ID: 991103000001477003
Triggered by: automation.sendSequencedEmail, dispatched by routeContactSequence as the side email after a Demo Hosted cadence call is logged not-connected (handleCallOutcome, call:neutral), or as cadence step 3.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact at the Demo Hosted stage (demo not yet held), mid-cadence. Sender is the Deal Owner.

Subject:
Keeping things moving for ${!Contacts.Account_Name.Account_Name}

Body:
Hi ${!Contacts.First_Name},

Checking in on where things stand. Whenever the timing is right, I can get a walkthrough set up for ${!Contacts.Account_Name.Account_Name}, shaped around what matters most to you rather than a standard run-through. Just reply and I'll sort a time.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!users.first_name}, ${!userSignature}. Preserved from live (no booking link present live; kept reply-based to match).
Guaranteed by trigger: demo still outstanding. The live wording ("how you're thinking about next steps") could read as post-attendance; the draft keeps it firmly about getting the walkthrough set up, consistent with steps 1 and 2, so it never implies a demo already happened.
Single call to action: reply to arrange a time.
Divergence from live: reframed to a demo-to-be-held reconnection to keep the family consistent and safe. Live copy contained an em dash; removed.
Open question: confirm the Demo Hosted family is intended as demo recovery (demo not yet held) throughout, given the stage name; steps 1 and 2 clearly are, and this draft aligns 3 to 5 with that reading.
