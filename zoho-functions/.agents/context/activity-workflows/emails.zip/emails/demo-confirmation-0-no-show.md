Template name: Demo Confirmation - No-Show
Template ID: 991103000001476010
Triggered by: automation.sendSequencedEmail (kind demo_no_show), dispatched by routeContactSequence from the demo:noshow branch when a booked demo is missed (handleMeetingEvent). Note: on the demo:followup recovery path this side email is deliberately suppressed.
Pipeline context: B2B pipeline only. Recipient is the Deal's Contact who missed a booked demo. Sender is the Deal Owner. Reschedule link ${!users.website}.

Subject:
Sorry we missed each other, let's find another time

Body:
Hi ${!Contacts.First_Name},

We had a demo in the diary but didn't manage to connect. No problem at all, these things happen. I'd still like to show ${!Contacts.Account_Name.Account_Name} what ${!org.company_name} can do.

Whenever it suits, you can pick a new time here: ${!users.website}.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.website}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: a booked demo was missed. Copy never implies the recipient attended; it treats the miss lightly and offers rebooking.
Single call to action: pick a new time via the link.
Divergence from live: unchanged except the subject, where a hyphen dash was replaced with a comma. Body contained an em dash; removed.
