Template name: Onboarding - Agreement Confirmed
Template ID: 991103000001488004
Triggered by: automation.sendSequencedEmail (kind commercials_signed_confirmation), dispatched from processDeal on the Onboarding floor-crossing (a confirmed, signed Quote pushes the Deal into Onboarding: crossedIntoOnboarding and signedTermExists and a Primary Contact present). Not sent from the old commercial:signed branch.
Pipeline context: B2B pipeline only. Recipient is the Primary Contact whose agreement has just been confirmed. Sender is the Deal Owner.

Subject:
Welcome aboard, your agreement is confirmed

Body:
Hi ${!Contacts.First_Name},

Thank you. The agreement for ${!Contacts.Account_Name.Account_Name} is confirmed, and we're glad to have you on board with ${!org.company_name}.

I'll be in touch shortly to get onboarding underway. If anything comes up before then, just reply.

Best regards,
${!users.first_name}
${!org.company_name}
${!userSignature}

Implementation notes:
Merge fields: ${!Contacts.First_Name}, ${!Contacts.Account_Name.Account_Name}, ${!org.company_name}, ${!users.first_name}, ${!userSignature}. Preserved from live.
Guaranteed by trigger: the agreement is signed and confirmed. Copy welcomes the client and sets the expectation that onboarding follows.
No manufactured call to action: the next action is Jurnii's (start onboarding). The reply option is a soft aid only.
This is the email that previously leaked to never-activated imported Contacts; the send-time activation gate in sendSequencedEmail is the fix. Content is unaffected. Live copy contained an em dash; removed and the subject hyphen dash replaced with a comma.
