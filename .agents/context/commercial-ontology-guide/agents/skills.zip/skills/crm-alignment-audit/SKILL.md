---
name: crm-alignment-audit
description: Generates a CRM implementation guide from extracted ontology — schema-copy parity, typed coordinates, campaign coverage matrix, and qualification gates. Use for Phase 4 of a website ontology audit. Does not connect to a live CRM.
---

# CRM Alignment Audit

## Quick start

1. Read all prior outputs from `/mnt/user/outputs/` (01, 02, 03)
2. Generate four deliverables: parity matrix, typed coordinates, campaign matrix, qualification gates
3. Write JSON to `/mnt/user/outputs/04-crm-alignment-audit.json`

## Schema-copy parity

Map every website entity to a recommended CRM field. All fields MUST use bounded lookup tables, not free text.

| Entity Type | CRM Field | Field Type |
|:---|:---|:---|
| Product | `product_name` | Lookup |
| Feature | `feature_name` | Lookup |
| Solution | `solution_name` | Lookup |
| Use Case | `use_case_field` | Lookup |
| Persona | `persona_type` | Enum |

## Campaign matrix

Generate: `Products × Persona Types × Opportunity Types × Use Case Values = Campaigns`

Flag any combination without a Campaign.

## Qualification gates

Define as boolean conditions, not subjective estimates:
- MQL → SQL: Budget > threshold AND Decision Maker identified
- SQL → FTP: Contract reviewed AND technical validation complete

## Detailed rules and output schema

→ See [REFERENCE.md](REFERENCE.md)
