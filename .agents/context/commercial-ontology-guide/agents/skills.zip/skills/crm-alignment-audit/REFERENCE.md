# CRM Alignment Audit Skill

> CRM schema alignment and implementation guide for Phase 4.

---

## Purpose

Generate a CRM implementation guide from the extracted ontology. This agent does NOT connect to a live CRM. It produces the recommended schema, campaign matrix, and qualification gates.

---

## Input

Read from `/mnt/session/outputs/`:
- `01-ontology-extraction.json` — entity inventory
- `02-architecture-audit.json` — site structure
- `03-copy-grammar-audit.json` — copy grammar

---

## 4.1 Schema–Copy Parity

For every entity in Phase 1, define the CRM field:

| Entity Type | CRM Field | Field Type | Table |
|:---|:---|:---|:---|
| Product | `product_name` | Lookup (bounded) | `Products` |
| Feature | `feature_name` | Lookup (bounded) | `Features` |
| Solution | `solution_name` | Lookup (bounded) | `Solutions` |
| Use Case | `use_case_field` | Lookup (bounded) | `UseCases` |
| Value | `use_case_value` | Enum within field | `UseCaseValues` |
| Persona | `persona_type` | Enum | `Personas` |

**Checks:**
- Every website entity → corresponding CRM field (no content gaps)
- Every CRM field → corresponding website content (no data gaps)
- All fields use lookup tables, not free text

## 4.2 Typed Coordinates

Map site interactions to CRM events:

| Page Type | CRM Event | Fields Populated |
|:---|:---|:---|
| Feature page view | Feature interaction | `feature_id`, `contact_id`, `timestamp` |
| Solution page view | Solution interaction | `solution_id`, `contact_id`, `timestamp` |
| Form submit | Lead creation | `contact_id` + all populated fields |

**Checks:**
- Minimum viable form ≤ 5 fields (behaviour provides the rest)
- Document behaviour-inferred vs form-required fields

## 4.3 Campaign Coverage Matrix

Generate: `Products × Persona Types × Opportunity Types × Use Case Values = Campaigns`

Flag any combination without a Campaign.

## 4.4 Qualification Gates

Define as boolean conditions, not subjective estimates:

| Gate | Condition |
|:---|:---|
| MQL → SQL | Budget > threshold AND Decision Maker identified |
| SQL → FTP | Contract reviewed AND technical validation complete |
| FTP → RTP | Contract signed AND payment processed |

---

## Output Schema

Write to `/mnt/session/outputs/04-crm-alignment-audit.json`:

```json
{
  "schema_parity": {
    "entities_on_site": 16,
    "recommended_crm_fields": 16,
    "content_gaps": [],
    "data_gaps": [],
    "free_text_violations": [],
    "score": "PASS"
  },
  "typed_coordinates": {
    "interaction_types_defined": 5,
    "minimum_form_fields": ["email", "first_name", "company"],
    "behaviour_inferred_fields": ["product_interest", "feature_interest"],
    "score": "PASS"
  },
  "campaign_matrix": {
    "total_campaigns": 48,
    "coverage_gaps": [],
    "score": "PASS"
  },
  "qualification_gates": {
    "gates_defined": 3,
    "all_boolean": true,
    "automatable": true,
    "score": "PASS"
  },
  "crm_implementation_guide": {
    "tables": ["Organisations", "Brands", "Products", "Features", "ProductFeatures", "Solutions", "FeatureSolutions", "UseCases", "UseCaseValues", "Personas", "Pipelines", "Campaigns", "Contacts", "Accounts", "Activities"],
    "relationships": [
      "Organisations 1:M Brands",
      "Brands 1:M Products",
      "Products M:M Features (via ProductFeatures)",
      "Features M:M Solutions (via FeatureSolutions)",
      "Pipelines 1:M Campaigns",
      "Contacts M:1 Accounts"
    ]
  },
  "overall_score": "PASS",
  "top_remediation_priorities": []
}
```
