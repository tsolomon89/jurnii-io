---
name: compound-effects-assessment
description: Synthesises audit outputs into a compound effects scorecard — site, pipeline, marketing, team/cultural, and compounding asset effects. Use for Phase 5 of a website ontology audit.
---

# Compound Effects Assessment

## Quick start

1. Read all prior outputs from `/mnt/user/outputs/` (01 through 04)
2. Score five categories against evidence from earlier phases
3. Write JSON to `/mnt/user/outputs/05-compound-effects.json`

## Scorecard categories

| Category | Key Checks | Evidence Source |
|:---|:---|:---|
| Site Effects | Self-qualification structural, pages short+numerous, cross-linking automatic | Phase 2 |
| Pipeline Effects | Forms ≤5 fields, pre-populated context, boolean gates | Phase 4 |
| Marketing Effects | Single-variable experiments, attribution is a query, bounded inventories | Phases 1+4 |
| Team/Cultural | Vocabulary aligned, knowledge structural, handoff friction decreased | Phases 1+3 |
| Compounding Asset | Every new page adds to same dataset, Won/Lost refines graph | Phases 2+4 |

## Scoring scale

- **STRONG** — all checks evidence positive outcome
- **EMERGING** — some checks pass, trajectory positive
- **NOT YET** — fundamental prerequisites missing

## Detailed criteria and output schema

→ See [REFERENCE.md](REFERENCE.md)
