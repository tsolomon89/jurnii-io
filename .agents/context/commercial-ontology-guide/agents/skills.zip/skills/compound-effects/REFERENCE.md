# Compound Effects Skill

> Measurement scorecard for Phase 5 of the Commercial Ontology Framework audit.

---

## Purpose

Synthesise outputs from Phases 1–4 into a compound effects scorecard. Assess whether the alignment is producing the expected downstream benefits.

---

## Input

Read all outputs from `/mnt/session/outputs/`:
- `01-ontology-extraction.json`
- `02-architecture-audit.json`
- `03-copy-grammar-audit.json`
- `04-crm-alignment-audit.json`

---

## Scorecard Sections

### Site Effects

| Check | Expected Outcome | Evidence Source |
|:---|:---|:---|
| Self-qualification is structural | Navigation-based, not copy-dependent | Phase 2: self_qualification score |
| Pages are shorter and more numerous | One subject per page | Phase 2: pillar_coverage |
| Cross-linking is automatic | From relational graph | Phase 2: relational_graph score |
| SEO: internal linking density | Meaningful page hierarchy present | Phase 2: url_structure |

### Pipeline Effects

| Check | Expected Outcome | Evidence Source |
|:---|:---|:---|
| Forms are shorter | ≤ 5 fields | Phase 4: minimum_form_fields |
| Reps have pre-populated context | Browsing behaviour feeds CRM | Phase 4: typed_coordinates |
| Qualification is hypothesis-testing | Boolean gates, not guesswork | Phase 4: qualification_gates |
| Pipeline hygiene automated | Stage transitions via Activity outcomes | Phase 4: qualification_gates.automatable |

### Marketing Effects

| Check | Expected Outcome | Evidence Source |
|:---|:---|:---|
| Experiments isolate one variable | Single-subject assets | Phase 1: features/solutions extraction |
| Attribution is a query | Typed coordinates enable it | Phase 4: typed_coordinates |
| Inventories are bounded | Controlled growth | Phase 1: summary.total_entities |

### Team & Cultural Effects

| Check | Expected Outcome | Evidence Source |
|:---|:---|:---|
| Vocabulary aligned across teams | Same entity names everywhere | Phase 1 + Phase 3 consistency |
| Knowledge is structural | Onboarding via ontology walk | Phase 1: entity completeness |
| Handoff friction decreased | Typed coordinates shared | Phase 4 |
| Strategic debates use typed entities | Not vague language | Overall compliance |

### Compounding Asset

| Check | Expected Outcome | Evidence Source |
|:---|:---|:---|
| Every new page adds to same dataset | No fragmentation | Phase 2: pillar_coverage |
| Won/Lost Activities refine the graph | Qualification loop active | Phase 4: qualification_gates |
| Model accuracy improves over time | Predictable from structure | Overall architecture |

---

## Scoring

Each section: `STRONG` / `EMERGING` / `NOT YET`

- **STRONG**: All checks evidence positive outcome
- **EMERGING**: Some checks pass, trajectory is positive
- **NOT YET**: Fundamental prerequisites missing

---

## Output Schema

Write to `/mnt/session/outputs/05-compound-effects.json`:

```json
{
  "site_effects": { "score": "EMERGING", "checks_passed": 3, "checks_total": 4, "notes": [] },
  "pipeline_effects": { "score": "STRONG", "checks_passed": 4, "checks_total": 4, "notes": [] },
  "marketing_effects": { "score": "EMERGING", "checks_passed": 2, "checks_total": 3, "notes": [] },
  "team_cultural_effects": { "score": "NOT YET", "checks_passed": 1, "checks_total": 4, "notes": ["Vocabulary not yet aligned across marketing and sales teams"] },
  "compounding_asset": { "score": "EMERGING", "checks_passed": 2, "checks_total": 3, "notes": [] },
  "overall_readiness": "EMERGING",
  "summary": "The framework's structural prerequisites are largely in place. Team adoption and vocabulary alignment are the primary blockers to compound returns."
}
```
