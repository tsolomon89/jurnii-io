---
name: architecture-audit
description: Audits website information architecture against the Commercial Ontology Framework — four content pillars, URL structure, relational graph, and self-qualification design. Use for Phase 2 of a website ontology audit.
---

# Architecture Audit

## Quick start

1. Read the Phase 1 extraction from `/mnt/user/outputs/01-ontology-extraction.json`
2. Use web_fetch to verify live site structure
3. Score four sections, write JSON to `/mnt/user/outputs/02-architecture-audit.json`

## Four pillars of content

Every page must serve exactly one cognitive function:

| Pillar | Function | URL Pattern |
|:---|:---|:---|
| Products | "What can I buy?" | `/products/[name]` |
| Features | "What does it include?" | `/features/[name]` |
| Solutions | "What does it do for me?" | `/solutions/[name]` |
| Use Cases | "How was it used by someone like me?" | `/use-cases/[value]` |

## Checks

**Pillar coverage**: Can every page be classified into one pillar? Flag conflated pages.

**URL structure**: Noun-based hierarchy? Flag verb-based or campaign-specific URLs.

**Relational graph**: Feature→Product, Solution→Feature, UseCase→Solution cross-links present?

**Self-qualification**: Navigation-based qualification? One subject per page? More pages, less content?

## Scoring

`PASS` — all checks satisfied | `PARTIAL` — fixable gaps | `FAIL` — structural redesign needed

## Detailed audit rules

For complete pillar specifications, anti-patterns, and output JSON schema:
→ See [REFERENCE.md](REFERENCE.md)
