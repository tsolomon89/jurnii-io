# Architecture Audit Skill

> Website architecture evaluation rules for Phase 2 of the Commercial Ontology Framework audit.

---

## Purpose

Given the Phase 1 ontology extraction (`01-ontology-extraction.json`) and the target website URL, audit the site's information architecture against the framework's structural requirements.

---

## Input

Read `/mnt/session/outputs/01-ontology-extraction.json` for the entity inventory. Use `web_fetch` to verify live site structure.

---

## Audit Sections

### 2.1 Four Pillars of Content

Every page must serve exactly one of four cognitive functions:

| Pillar | Cognitive Function | Content Type | Expected URL Pattern |
|:---|:---|:---|:---|
| **Products** | "What can I buy?" | Transactional, definitive | `/products/[name]` |
| **Features** | "What does it include?" | Informative, structural | `/features/[name]` or `/subjects/[name]` |
| **Solutions** | "What does it do for me?" | Empathetic, action-oriented | `/solutions/[name]` or `/services/[name]` |
| **Use Cases** | "How was it used by someone like me?" | Social proof, success stories | `/use-cases/[value]` or `/reviews/[audience]` |

**Checks:**
- Can every page be classified into exactly one pillar?
- Are there pages that conflate two or more pillars?
- Are there pillar gaps (entities in database with no corresponding page)?
- Does each pillar page cross-link to related pages in other pillars?

### 2.2 URL Structure

**Checks:**
- Does URL hierarchy reflect the ontology (broad → specific)?
- Are URLs stable noun-based paths (not verb-based or campaign-specific)?
- Does nesting support hierarchical SEO progression?
- Are there orphan pages outside the hierarchy?

**Anti-patterns to flag:**
- `/get-started-with-automation` (verb-based)
- `/campaign-q3-2025` (campaign-specific)
- `/page-1` (meaningless slug)

### 2.3 Relational Graph on the Frontend

**Checks:**
- Does each Feature page list every Product the Feature appears in?
- Does each Solution page list every Feature the Solution applies to?
- Does each Use Case page cross-reference Solutions and Personas?
- Does each Product page surface its Features, Solutions, and Use Cases?
- Can a buyer who lands on the wrong front door find the right one in ≤ 2 clicks?

### 2.4 Self-Qualification Architecture

**Checks:**
- Does the site allow buyers to self-qualify through navigation (not reading long copy)?
- Are pages short and focused (one subject per page)?
- Is there more pages with less content, rather than fewer pages with everything?

---

## Scoring Rubric

Score each section on a 3-point scale:

| Score | Meaning |
|:---|:---|
| `PASS` | All checks satisfied |
| `PARTIAL` | Some checks fail but fixable with content restructuring |
| `FAIL` | Fundamental structural issues requiring architectural redesign |

---

## Output Schema

Write to `/mnt/session/outputs/02-architecture-audit.json`:

```json
{
  "audit_target": "https://example.com",
  "pillar_coverage": {
    "products": { "pages_found": 3, "entities_in_ontology": 3, "gaps": [], "score": "PASS" },
    "features": { "pages_found": 8, "entities_in_ontology": 12, "gaps": ["Workflows", "Segments", "Dashboards", "Reports"], "score": "PARTIAL" },
    "solutions": { "pages_found": 0, "entities_in_ontology": 5, "gaps": ["Automation", "Scoring", "Routing", "Reporting", "Forecasting"], "score": "FAIL" },
    "use_cases": { "pages_found": 4, "entities_in_ontology": 4, "gaps": [], "score": "PASS" }
  },
  "conflated_pages": [
    { "url": "/platform", "pillars_mixed": ["Products", "Features", "Solutions"], "recommendation": "Split into separate Product overview + Feature index + Solution index" }
  ],
  "url_structure": {
    "noun_based": true,
    "hierarchical": false,
    "orphan_pages": ["/demo", "/thank-you"],
    "anti_patterns": ["/get-started-now"],
    "score": "PARTIAL"
  },
  "relational_graph": {
    "feature_to_product_links": false,
    "solution_to_feature_links": false,
    "use_case_cross_references": true,
    "two_click_reachability": false,
    "score": "FAIL"
  },
  "self_qualification": {
    "navigation_based": false,
    "single_subject_pages": false,
    "page_density": "low",
    "score": "FAIL"
  },
  "overall_score": "PARTIAL",
  "top_remediation_priorities": [
    "Create dedicated Solution pages for all 5 extracted Solutions",
    "Split /platform into separate pillar pages",
    "Add Feature→Product and Solution→Feature cross-links on all pages"
  ]
}
```
