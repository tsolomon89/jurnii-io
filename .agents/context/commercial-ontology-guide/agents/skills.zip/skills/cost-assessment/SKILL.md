---
name: cost-assessment
description: Estimates real transition costs for adopting the Commercial Ontology Framework — retagging, rewriting, learning curve, and transition quarter impacts. Use for Phase 6 of a website ontology audit.
---

# Cost Assessment

## Quick start

1. Read all prior outputs from `/mnt/user/outputs/` (01 through 04)
2. Calculate four cost categories using the formulas below
3. Write JSON to `/mnt/user/outputs/06-cost-assessment.json`

## Cost formulas

### Retagging
`(pages + assets + CRM fields) × 0.25 hours`
- Pages: total from Phase 2
- Assets: estimated at 3× page count
- CRM fields: free-text violations from Phase 4

### Rewriting
`(splits + new_pages + h1_fixes + decompositions) × 2 hours`
- Splits: conflated pages from Phase 2
- New pages: pillar gaps from Phase 2
- H1 fixes: violations from Phase 3
- Decompositions: compound phrases from Phase 3

### Learning curve
- 2–3 training sessions × 2 hours each
- First quarter at ~70% creative velocity
- 8–16 hours documentation creation

### Transition quarter
- 4–6 weeks parallel-run period
- Historical data not directly comparable across boundary
- ~30% creative velocity reduction in Q1

## HONESTY RULE

Estimates MUST be realistic, not optimistic. Round UP, not down.

## Detailed formulas and output schema

→ See [REFERENCE.md](REFERENCE.md)
