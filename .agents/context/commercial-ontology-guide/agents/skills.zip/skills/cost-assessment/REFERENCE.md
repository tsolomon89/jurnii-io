# Cost Assessment Skill

> Transition cost estimation for Phase 6 of the Commercial Ontology Framework audit.

---

## Purpose

Estimate the real costs of transitioning to the Commercial Ontology Framework. Provide honest, actionable cost projections so stakeholders have accurate expectations.

---

## Input

Read all outputs from `/mnt/session/outputs/`:
- `01-ontology-extraction.json` — entity counts drive retagging estimates
- `02-architecture-audit.json` — structural gaps drive rewriting estimates
- `03-copy-grammar-audit.json` — violation counts drive copy revision estimates
- `04-crm-alignment-audit.json` — schema gaps drive CRM migration estimates

---

## Cost Categories

### Retagging

Estimate the effort to classify existing content against the ontology.

| Factor | Calculation |
|:---|:---|
| Pages to classify | Total pages from Phase 2 |
| Assets to retag | Estimated at 3× page count (images, PDFs, videos) |
| CRM fields to reclassify | Free-text violations from Phase 4 |
| Time per page | ~15 minutes for classification + metadata |
| Total hours | `(pages + assets + fields) × 0.25 hours` |

### Rewriting

Estimate the effort to fix structural and grammar violations.

| Factor | Calculation |
|:---|:---|
| Pages to split | Conflated pages from Phase 2 |
| New pages needed | Pillar gaps from Phase 2 |
| Headlines to rewrite | H1 violations from Phase 3 |
| Compositions to decompose | Compound phrases from Phase 3 |
| Time per page | ~2 hours for rewrite + review |
| Total hours | `(splits + new_pages + h1_fixes + decompositions) × 2 hours` |

### Learning Curve

| Factor | Estimate |
|:---|:---|
| Team training sessions | 2–3 sessions of 2 hours each |
| Ramp-up quarter | First quarter at ~70% creative velocity |
| Documentation creation | 8–16 hours for internal playbooks |

### Transition Quarter

| Factor | Impact |
|:---|:---|
| Parallel-run period | 4–6 weeks running old and new systems |
| Reporting gap | Historical data not directly comparable across boundary |
| Creative velocity dip | ~30% reduction during first quarter |

---

## Output Schema

Write to `/mnt/session/outputs/06-cost-assessment.json`:

```json
{
  "retagging": {
    "pages_to_classify": 45,
    "assets_to_retag": 135,
    "crm_fields_to_reclassify": 3,
    "estimated_hours": 46,
    "estimated_weeks": "2-3 weeks (1 FTE)"
  },
  "rewriting": {
    "pages_to_split": 5,
    "new_pages_needed": 9,
    "headlines_to_rewrite": 7,
    "compositions_to_decompose": 4,
    "estimated_hours": 50,
    "estimated_weeks": "3-4 weeks (1 FTE)"
  },
  "learning_curve": {
    "training_sessions": 3,
    "training_hours": 6,
    "documentation_hours": 12,
    "ramp_up_velocity": "70% for first quarter"
  },
  "transition_quarter": {
    "parallel_run_weeks": 5,
    "reporting_gap": true,
    "creative_velocity_impact": "-30%"
  },
  "total_estimate": {
    "total_hours": 114,
    "calendar_weeks": "6-8 weeks",
    "team_size_recommended": "1-2 FTE",
    "roi_break_even": "Quarter 2 post-transition"
  },
  "summary": "Transition requires approximately 114 hours of focused work over 6-8 weeks. Expect a 30% creative velocity dip in Q1 with break-even by Q2."
}
```
