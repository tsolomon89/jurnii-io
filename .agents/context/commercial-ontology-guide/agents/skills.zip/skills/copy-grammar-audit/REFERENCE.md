# Copy Grammar Audit Skill

> Copy and headline grammar evaluation rules for Phase 3 of the Commercial Ontology Framework audit.

---

## Purpose

Given the Phase 1 ontology extraction and the target website URL, audit every page's copy grammar — headlines, navigation labels, and tone — against the framework's linguistic rules.

---

## Input

Read `/mnt/session/outputs/01-ontology-extraction.json`. Use `web_fetch` to read live page content.

---

## Audit Sections

### 3.1 Headline & H1 Compliance

Each page's `<h1>` must use the correct grammar for its pillar:

| Pillar | Required H1 Grammar | Example ✅ | Example ❌ |
|:---|:---|:---|:---|
| Product | Noun phrase | "Revenue Platform" | "Grow Your Revenue" |
| Feature | Object noun | "Contacts" | "Managing Your Contacts" |
| Solution | Nominalised operator or action phrase | "Automation" | "We Automate Everything" |
| Use Case | Value label + context | "SaaS Marketing" | "How SaaS Companies Win" |

**Checks:**
- Collect every page's H1 tag
- Classify the page into its pillar (from Phase 2 output or inferred)
- Evaluate H1 grammar against the pillar's rule
- Confirm H1s are unique across all pages (no duplicates)

### 3.2 Composition vs. Atom

Scan all headlines and navigation labels for compound phrases that should be decomposed:

| Compound Found | Decomposition | Status |
|:---|:---|:---|
| "Lead Scoring" | Feature=`Leads` + Solution=`Scoring` | ❌ VIOLATION |
| "Email Automation" | Feature=`Emails` + Solution=`Automation` | ❌ VIOLATION |
| "Contact Management" | Feature=`Contacts` + Solution=`Management` | ❌ VIOLATION |
| "Contacts" | Atomic Feature | ✅ COMPLIANT |

**Check:** Verify the ontology preserves both parts separately in the data layer.

### 3.3 Tone Strategy by Persona Type

When marketing assets target different Personas, tone must shift:

| Persona Type | Required Tone | Focus | Example CTA |
|:---|:---|:---|:---|
| **Decision Maker** | Reliable, reassuring, results-oriented | Track record, financial value, guaranteed outcomes | "Schedule a Free Consultation" |
| **Influencer** | Professional, objective, data-driven | Certifications, expertise, statistical proof | "Explore Our Programs" |
| **End User** | Relatable, engaging, empathetic, informal | Self-improvement, usability, capability | "Discover Your Potential" |

**Checks:**
- Are assets differentiated by Persona Type?
- Does the "All" classifier correctly leave room for multi-persona pages?
- Are homepages using `personaType = All` and routing to persona-specific pages?
- Flag any page where tone is mismatched to its audience (e.g., DM page using casual End User language)

### 3.4 Anti-Patterns

Flag these copy anti-patterns on sight:

| Anti-Pattern | What's Wrong | Fix |
|:---|:---|:---|
| Product named as verb/claim | "Helps Teams Grow" | Rename to noun phrase: "Revenue Platform" |
| Feature named as composition | "Lead Scoring" | Decompose: Feature=Leads, Solution=Scoring |
| Solution as conjugated verb | "Automates" | Nominalise: "Automation" |
| Use Case is a description | "Healthcare companies" | Separate: Use Case=Industry, Value=Healthcare |
| Persona is a narrative | "Sarah cares about efficiency" | Structure: DM + {field: value, field: value} |
| Same content on multiple pillars | Product page also serves as Use Case page | Split into separate typed pages |

---

## Output Schema

Write to `/mnt/session/outputs/03-copy-grammar-audit.json`:

```json
{
  "audit_target": "https://example.com",
  "h1_compliance": {
    "total_pages_checked": 25,
    "compliant": 18,
    "violations": [
      { "url": "/products/platform", "h1": "Grow Your Revenue", "pillar": "Product", "expected_grammar": "noun phrase", "recommendation": "Revenue Platform" }
    ],
    "duplicates": [],
    "score": "PARTIAL"
  },
  "composition_decomposition": {
    "compounds_found": 4,
    "decompositions": [
      { "compound": "Lead Scoring", "feature": "Leads", "solution": "Scoring", "locations": ["/features/lead-scoring", "/nav"] }
    ],
    "score": "FAIL"
  },
  "tone_strategy": {
    "persona_differentiated": false,
    "all_classifier_used": true,
    "mismatches": [
      { "url": "/enterprise", "detected_persona": "Decision Maker", "detected_tone": "casual/End User", "recommendation": "Shift to results-oriented, ROI-focused language" }
    ],
    "score": "PARTIAL"
  },
  "anti_patterns": [
    { "pattern": "Product named as verb/claim", "instances": 1, "locations": ["/products/platform"] }
  ],
  "overall_score": "PARTIAL",
  "top_remediation_priorities": [
    "Rename H1 on /products/platform from 'Grow Your Revenue' to 'Revenue Platform'",
    "Decompose 4 compound Feature+Solution names in navigation",
    "Differentiate copy tone between DM and EU landing pages"
  ]
}
```
