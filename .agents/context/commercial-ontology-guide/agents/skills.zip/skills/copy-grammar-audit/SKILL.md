---
name: copy-grammar-audit
description: Audits website copy grammar — H1 compliance per content pillar, composition decomposition, tone strategy by Persona Type, and anti-pattern detection. Use for Phase 3 of a website ontology audit.
---

# Copy Grammar Audit

## Quick start

1. Read Phase 1 extraction from `/mnt/user/outputs/01-ontology-extraction.json`
2. Use web_fetch to collect H1 tags, nav labels, CTAs from the live site
3. Score four sections, write JSON to `/mnt/user/outputs/03-copy-grammar-audit.json`

## H1 rules by pillar

| Pillar | Required H1 Grammar | Example ✅ | Example ❌ |
|:---|:---|:---|:---|
| Product | Noun phrase | "Revenue Platform" | "Grow Your Revenue" |
| Feature | Object noun | "Contacts" | "Managing Your Contacts" |
| Solution | Nominalised operator | "Automation" | "We Automate Everything" |
| Use Case | Value + context | "SaaS Marketing" | "How SaaS Companies Win" |

## Composition decomposition

Flag compound phrases. Decompose: "Lead Scoring" → Feature=`Leads` + Solution=`Scoring`

## Tone strategy

| Persona Type | Tone | Focus |
|:---|:---|:---|
| Decision Maker | Reliable, results-oriented | ROI, track record |
| Influencer | Professional, data-driven | Certifications, proof |
| End User | Relatable, empathetic | Usability, self-improvement |

## Anti-patterns to flag

- Product named as verb/claim
- Feature named as composition
- Solution as conjugated verb
- Same content on multiple pillars

## Detailed rules and output schema

→ See [REFERENCE.md](REFERENCE.md)
