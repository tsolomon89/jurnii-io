---
name: ontology-extraction
description: Extracts commercial entities (Brand, Products, Features, Solutions, Use Cases, Personas) from a target website. Use when crawling a site to build its ontology inventory for the Commercial Ontology Framework audit Phase 1.
---

# Ontology Extraction

## Quick start

1. Crawl the target site starting from homepage navigation
2. Extract all six entity types using the grammar rules below
3. Write structured JSON to `/mnt/user/outputs/01-ontology-extraction.json`

## Entity grammar rules

| Entity | Grammar | Max Length | Example ✅ | Example ❌ |
|:---|:---|:---|:---|:---|
| Brand | Root identity string | — | "Acme" | — |
| Product | Stable noun phrase | ≤4 words, ≤50 chars | "Revenue Platform" | "Helps Teams Grow" |
| Feature | Object noun | ≤2 words, ≤30 chars | "Contacts" | "Lead Scoring" |
| Solution | Nominalised operator | ≤2 words, ≤30 chars | "Automation" | "Automates" |
| Use Case | Field noun (not value) | ≤30 chars | "Industry" | "Healthcare companies" |
| Persona | Type + structured values | — | DM + {Dept: Marketing} | "Sarah cares about efficiency" |

## Crawl strategy

- Follow primary navigation links (Products, Features, Solutions, Pricing, About)
- Crawl up to 50 pages. Skip blogs, news, legal, support
- Prioritise: product pages, feature pages, pricing, use case pages

## Composition test

If a name encodes Feature+Solution (e.g. "Lead Scoring"), decompose:
- Feature = `Leads`, Solution = `Scoring`
- Both parts must exist separately in the data layer

## Detailed extraction rules

For complete entity specifications, validation criteria, and output JSON schema:
→ See [REFERENCE.md](REFERENCE.md)
