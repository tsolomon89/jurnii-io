# Ontology Extraction Skill

> Entity extraction rules for Phase 1 of the Commercial Ontology Framework audit.

---

## Purpose

Given a target website URL, crawl the site and extract the six core commercial entity types. Produce a structured extraction report that downstream agents consume.

---

## Crawl Strategy

1. Fetch the homepage. Identify the primary navigation structure.
2. Follow all top-level navigation links (Products, Features, Solutions, Pricing, About, Use Cases, Industries, etc.).
3. For each navigation section, fetch up to 20 child pages.
4. Parse pricing pages, footer links, and any "platform" or "overview" pages.
5. Do NOT crawl blog posts, news articles, legal pages, or support/help docs unless they contain product/feature definitions.

---

## Entity Extraction Rules

### 1. Brand

| Check | Rule |
|:---|:---|
| Identity | The root name between the subdomain and TLD (e.g., `acme` in `www.acme.com`) |
| Consistency | Confirm the same string appears in page titles, logo alt text, footer, and social links |
| Sub-brands | List any distinct brand names operating under the same organisation |

### 2. Products

| Check | Rule |
|:---|:---|
| Identification | Every offering, platform, or system being sold, adopted, or licensed |
| Name grammar | Must be a **stable noun phrase** (no verbs, claims, or taglines) |
| Name length | ≤ 4 words, ≤ 50 characters |
| Pricing | Document default pricing, contract duration, billing frequency if visible. Mark `MISSING` if not |
| Pipeline type | Classify as: `B2B`, `B2C`, `Reseller`, `Partnership`, or `Investment` |

**Violation example**: "Helps Teams Grow" → should be noun phrase like "Revenue Platform"

### 3. Features

| Check | Rule |
|:---|:---|
| Identification | Native objects a Product supports (what it *has*) |
| Name grammar | **Object noun**, ≤ 2 words, ≤ 30 characters |
| Composition test | If the name encodes Feature+Solution (e.g., "Lead Scoring"), decompose: Feature=`Leads`, Solution=`Scoring` |
| Sharing | Note Features that appear across multiple Products (M:M relationship) |
| Pricing paradox | Flag any Feature carrying its own auxiliary pricing; document the exposure |

### 4. Solutions

| Check | Rule |
|:---|:---|
| Identification | Operators or processes applied to Features (what a Feature *does*) |
| Name grammar | **Nominalised operator**, ≤ 2 words, ≤ 30 characters |
| Verb test | Flag conjugated verbs ("Automates" → should be "Automation") |
| Reusability | Must apply to more than one Feature; otherwise it may be a Feature descriptor |
| Cost rule | Solutions carry zero intrinsic cost — all value traces to parent Features |

### 5. Use Cases

| Check | Rule |
|:---|:---|
| Identification | Targeting/segmentation fields (Sector, Industry, Department, Seniority, Company Size, Location, etc.) |
| Name grammar | **Field noun** — the category name, not its values |
| Value bundling | Flag any Use Case that is actually a Value bundle ("Healthcare companies" → Use Case=`Industry`, Value=`Healthcare`) |
| Bounded values | List the set of allowed Values for each field |
| Mutual exclusivity | Values within a field must be mutually exclusive |
| All/Other | Flag if no honest "Other" or "All" option exists |

### 6. Personas

| Check | Rule |
|:---|:---|
| Three types | Each Product should define: Decision Maker, End User, Influencer |
| Structure | Persona = Persona Type + structured set of Values across Use Case fields. Flag narrative blurbs/character sketches as `VIOLATION` |
| Dominance logic | Decision Maker classification supersedes all others |
| Product-relative | Each Product's Decision Maker is distinct from another Product's Decision Maker |

---

## Output Schema

Write the extraction report as JSON to `/mnt/session/outputs/01-ontology-extraction.json`:

```json
{
  "audit_target": {
    "url": "https://example.com",
    "crawl_timestamp": "2026-05-11T10:00:00Z",
    "pages_crawled": 45
  },
  "brand": {
    "name": "Example",
    "consistent": true,
    "sub_brands": [],
    "status": "COMPLIANT"
  },
  "products": [
    {
      "name": "Revenue Platform",
      "name_grammar": "COMPLIANT",
      "pipeline_type": "B2B",
      "pricing": { "visible": true, "default_price": "$99/mo", "billing": "monthly" },
      "status": "COMPLIANT",
      "violations": []
    }
  ],
  "features": [
    {
      "name": "Contacts",
      "parent_products": ["Revenue Platform"],
      "name_grammar": "COMPLIANT",
      "composition_test": "PASS",
      "auxiliary_pricing": false,
      "status": "COMPLIANT",
      "violations": []
    }
  ],
  "solutions": [
    {
      "name": "Automation",
      "applied_to_features": ["Contacts", "Leads"],
      "name_grammar": "COMPLIANT",
      "reusability": "PASS",
      "status": "COMPLIANT",
      "violations": []
    }
  ],
  "use_cases": [
    {
      "field_name": "Industry",
      "name_grammar": "COMPLIANT",
      "values": ["SaaS", "Healthcare", "Finance", "Other"],
      "mutually_exclusive": true,
      "has_other_all": true,
      "status": "COMPLIANT",
      "violations": []
    }
  ],
  "personas": [
    {
      "product": "Revenue Platform",
      "persona_type": "Decision Maker",
      "structured": true,
      "value_set": { "Department": "Marketing", "Seniority": "Director" },
      "status": "COMPLIANT",
      "violations": []
    }
  ],
  "summary": {
    "total_entities": { "products": 1, "features": 5, "solutions": 3, "use_cases": 4, "personas": 3 },
    "violations": { "products": 0, "features": 1, "solutions": 0, "use_cases": 0, "personas": 1 },
    "top_remediation_priorities": [
      "Decompose Feature 'Lead Scoring' into Feature=Leads + Solution=Scoring",
      "Structure Persona 'Sarah cares about efficiency' as DM + {Department: Marketing, Seniority: Director}"
    ]
  }
}
```

---

## Compliance Labels

Use these labels consistently:

| Label | Meaning |
|:---|:---|
| ✅ `COMPLIANT` | Meets all rules for this entity type |
| ❌ `VIOLATION` | Fails one or more rules — include specific rule reference |
| ⚠️ `PARTIAL` | Partially compliant — needs human review |
| 🔍 `MISSING` | Expected data not found on the site |
