---
type: Market Report
title: The UK iGaming Market Report, H1 2026
subtitle: Promotional intensity, margin discipline, and the experience layer in the first duty-compressed year
region: United Kingdom (GB)
author: Jurnii Intelligence
date: 2026-08-03
tagline: Where UX Meets Commercial Strategy
evidence_window: February to June 2026
data_basis: Jurnii 360 promotional intelligence (13,673 tracked UK events, 21 brands) · Jurnii UX journey benchmarks · public operator results
---

# The UK iGaming Market Report, H1 2026

*Promotional intensity, margin discipline, and the experience layer in the first duty-compressed year.*

---

## Executive summary

The UK's regulated betting and gaming market spent the first half of 2026 absorbing the single largest structural change in its recent history: a 40% Remote Gaming Duty. The duty did not simply raise costs. It changed the economics of promotion, accelerated consolidation, and moved the competitive contest from how much operators spend to how precisely they spend it.

Six findings define the half-year.

1. **The market is contracting in intensity, not activity.** Promotional intensity fell 10.3% month-on-month between the mid-March and mid-May windows, driven by shorter, thinner promotions rather than fewer of them. Boost volumes held roughly flat while promotion count fell 18.2%.
2. **Volume and voice have decoupled.** The operator running the most promotions in Britain, bet365 at 2,554 tracked events, holds one of the lowest shares of promotional voice at 4.1%. BoyleSports leads on voice at 19.6% from fewer than a quarter of that activity.
3. **Boost strategy has split into three camps.** William Hill has structurally escalated its boost spend; Paddy Power and bet365 hold disciplined, event-specific lines; and Entain's Ladbrokes and Coral run high headline percentages at a fraction of the margin cost.
4. **The World Cup exposed the gap between loud and generous.** Across the build-up, World Cup boosts carried a bigger median headline than normal football while conceding less margin. Most operators advertised generosity they did not fund.
5. **Consolidation is live.** A £225m bid for Evoke, budget cuts of 20 to 25% flagged across three major groups, and fresh challenger capital are reshaping the operator set inside a single year.
6. **Experience is the uncosted variable.** Journey scores across the market cluster in the 70s, with the same weak touchpoints recurring: game discovery, promotional transparency, and page performance. In a 40%-duty market, the friction that leaks hard-won first deposits is the most expensive line no media plan shows.

The through-line is simple. The 40% duty turned a spending contest into a precision contest. This report sets out what the data shows across four layers: the promotional market structure, boost economics, the event calendar, and the experience and corporate landscape.

---

## 1. Market context: the 40% duty reset the maths

The Remote Gaming Duty at 40% is now the defining condition of the British market. Its first-order effect is arithmetic. Every promotional pound costs materially more than it did a year earlier, on the order of 19p more per pound of promotional value. Its second-order effects are strategic, and they are already visible in the data.

The duty does not fall evenly. A UK-concentrated operator absorbs it undiluted; a multi-national spreads it across a global P&L. The disclosures make the divergence concrete. One major group booked a UK duty impairment charge of £488m within a £681m statutory loss for FY2025, while still reporting 15% UK online net gaming revenue growth and an eighth consecutive quarter of online growth. A NYSE-listed group put the group EBITDA impact of the UK duty at roughly 6% of its FY2026 base, against 2026 revenue guidance above $2.55bn. The tax is a single rate. The exposure to it is an operator-specific variable, and it is now a strategic one.

The response across the market has been to cut and to focus. Flutter, Betway, and Betfred have all flagged marketing budget reductions of 20 to 25%. That retreat creates a window: dislocated players moving from operators pulling back. Entain has explicitly cited benefiting from competitors exiting. Capturing that dislocation, however, requires knowing where rivals are actually pulling back, by product and by promotion type, in something closer to real time than a quarterly retrospect.

Two further structural conditions frame every commercial decision in the market. First, platform commoditisation: the majority of regulated British operators run on a small number of shared B2B stacks, competing on reskin rather than product. Second, player multi-homing: between 70% and 80% of UK players hold three to five accounts simultaneously, and the highest-value players are the most likely to switch. Together, these conditions remove the two traditional levers. Operators cannot outspend the market, because the duty has closed that door, and they cannot out-feature it, because the platform is shared. What remains is the efficiency of promotion and the quality of experience.

---

## 2. Promotional market structure

Between 23 February and 26 April 2026, Jurnii 360 tracked 13,673 promotional events across 21 UK brands. The structure that emerges is not a ranking of who is loudest. It is a ranking of who is heard.

### Share of Promotional Voice

Share of Promotional Voice is an intensity-weighted measure of promotional presence. It accounts for boost richness and time live, not just raw event count. A brand running fewer but richer, longer-lived offers can hold a larger share of voice than a brand running many thin ones.

| Brand | Share of Voice | Event volume | Median boost | Strategic signal |
|---|---|---|---|---|
| BoyleSports | 19.6% | 600 events, 102 boosts | 66.7% | Value-dense; highest richness in the market |
| Betfred | 12.2% | 1,252 events, 1,071 boosts | 20.0% | Volume and richness; gaining share |
| Unibet | 10.2% | 767 events, 688 boosts | 20.0% | Consistent, softening in period two |
| Paddy Power | 8.8% | 1,583 events, 1,400 boosts | 11.1% | Largest event count of the majors; retreated post-Cheltenham |
| Ladbrokes | 7.92% | 1,275 events, 1,173 boosts | 14.3% | Volume-led, at market-average richness |
| William Hill | 7.6% | 1,520 events, 1,352 boosts | 14.3% | Surged post-Aintree |
| Sky Bet | 7.6% | 435 events, 313 boosts | 25.0% | High-richness, low-volume |
| bet365 | 4.1% | 2,554 events, 2,491 boosts | 12.5% | Highest boost count, lowest voice |
| Midnite | 1.7% | 1,557 events, 1,534 boosts | 20.0% | 11.4% of all UK events, challenger volume play |

The headline is the inversion at the two ends. bet365 runs the most boosts in Britain and holds the lowest share of voice, because almost all of that activity is thin and single-day. BoyleSports runs a fraction of the events and leads the market, because its offers are dense and long-lived. Volume is easy to buy. Intensity is where the return lives, and operators that measure their own output rather than the market's intensity routinely confuse the two.

### The market is rotating, weekly

A month-on-month comparison, from the 30-day window ending 12 April to the 30-day window ending 12 May, shows a market contracting in intensity while remaining highly active.

- Total market intensity fell 10.3%, from 52,272 to 46,864 on the index.
- Promotion count fell 18.2%; boost count fell only 2.4%. The contraction is a shift to shorter, thinner offers, not a withdrawal.
- Price boosts rose to 45.3% of all promotional intensity, up 3.5 points, confirming a market-wide drift toward single-selection price mechanics.
- Share moved hands inside 30 days: Ladbrokes gained 2.4 points of voice, the largest gainer, while BoyleSports ceded 3.5 points, the largest faller.

The mechanic mix is consolidating around price. Product mix is rotating with the calendar: football rose from 10.0% to 13.9% of intensity as budget moved into the Premier League run-in, horse racing edged up, and bingo fell three points. Day-of-week patterns shifted too, with Saturday intensity down 26.5% as the racing calendar moved past Aintree, and Monday gaining share. None of these are annual movements. They are weekly, and an operator reviewing competitor activity quarterly is reading a market that has changed shape several times since the last snapshot.

---

## 3. Boost economics: generosity versus margin conceded

The most commercially important distinction in the UK market is the gap between what a boost advertises and what it actually concedes. Jurnii 360 measures both: the median headline boost percentage, and the margin conceded, which is the real probability the operator hands to the player. Across a 15-week window from 4 February to 13 May, three strategies separated cleanly.

| Strategy | Example | Median boost | Margin conceded | Efficiency (boost ÷ margin) |
|---|---|---|---|---|
| Structural escalation | William Hill | 20.0% (from 10.0% in Feb) | 3.57pp (from 1.28pp) | ~5.6× |
| Disciplined baseline | Paddy Power | 11.1% (flat) | 1.52pp | ~7.3× |
| Precision hold | bet365 | 14.3% (stable) | 1.19pp | ~12.0× |

William Hill roughly tripled its cost per boost across the spring and did not reverse after the racing calendar closed. That is a repositioning, not a festival spike, and it coincides with the operator's integration of a major acquired business. Paddy Power held an 11% floor for nine straight weeks, activated once for Cheltenham at 17.4% and 2.5pp, then reverted cleanly. bet365 barely moved, and finished the window with the lowest margin conceded in the dataset. By May, William Hill was conceding more than twice the margin per boost that Paddy Power was, for what are ostensibly similar products to the same customer base.

The four-brand spring view, which adds Ladbrokes, reveals a fourth model that reframes the whole picture. Ladbrokes ran a median boost of 16.7%, matching or exceeding William Hill week for week, at a margin conceded of just 1.12pp, comparable to bet365. Its efficiency ratio, boost percentage divided by margin, ran at roughly 14 to 20 times against William Hill's 5 to 7 times. The per-competition data explains how: on top-tier football, William Hill conceded 3.5 to 5.0 points of margin (up to 5.0pp on the Champions League) while Ladbrokes conceded well under 1 point on the same competitions (0.48pp on the Bundesliga, 0.50pp on La Liga). A high headline percentage on a longer-odds or efficiently structured selection costs the operator far less than the same percentage on a short-priced favourite. Ladbrokes is advertising generosity it can afford. William Hill is advertising generosity it is paying full price for.

### The World Cup build-up sharpened the pattern

In the build-up window from 5 May to 4 June, the market went from no World Cup activity to 86 tracked activations across 15 operators. The aggregate signal was counter-intuitive: World Cup boosts carried a bigger median headline than normal football, 15.4% against a 14.3% baseline, while conceding less margin, 1.58pp against 1.67pp. The sticker got bigger and the price got worse. Most operators protected margin on uncertain pre-tournament markets while still flying the tournament flag. bet365 pulled its own prices back harder still, from a 14.3% football norm to 9.5%.

Two exceptions proved the rule, and both belong to Entain. Coral and Ladbrokes, running near-identical countdown boosts off a shared trading desk, lifted both numbers. Coral ran a 41.4% median at 2.66pp; Ladbrokes ran 36.7% at 4.76pp. Those are real price moves, offering genuine value on marquee selections such as England outright and top-goalscorer markets. Everyone else advertised generosity they did not fund.

The commercial reading is the single most important discipline in the market. Loud and generous are not the same thing. Without measuring margin conceded, an operator cannot tell whether it is buying share or badging it, and cannot tell whether a competitor's 40% banner is a genuine threat or a bluff on a protected book.

---

## 4. The event calendar as a market driver

British promotional intensity is event-anchored, and 2026 offered a clean natural experiment in how event format shapes deployment. Jurnii 360 tracked the two premier racing festivals side by side.

During Cheltenham week (10 to 13 March), customers had access to 775 total racing offers: 166 traditional promotions plus 609 price boosts. During the Aintree Festival and Grand National (9 to 11 April), the figure was 381: 142 traditional promotions plus 239 boosts. Cheltenham carried 103% more total racing offers. Normalised per race, it deployed 91% more boosts, 21.8 per race against 11.4. The always-on promotional foundation, roughly 115 evergreen racing offers such as Best Odds Guaranteed and Extra Places, was identical across both events. The entire difference was event-specific activity and real-time boosting. The lesson for planners: multi-day festivals support sustained high-intensity boosting that a three-day meeting cannot match, and the boost, not the traditional promotion, is the flexible lever.

The brand-level split at these events also illustrated the market's strategic archetypes. Midnite led Cheltenham boost volume with 132 boosts at 12.6% average generosity, a mass-volume, lower-margin model. BoyleSports ran a handful of boosts at 48.9% average, a premium-value model. Paddy Power sat between them at high volume and mid-tier generosity. bet365 led Aintree deployment with 55 boosts.

The World Cup activation timeline showed the acquisition calendar taking the same shape. From late February, nine operators launched tournament-referencing offers, but only two built mechanics whose value was contingent on tournament results rather than a deposit bonus with a tournament logo. Spreadex offered a rolling reward, worth up to £100 in free bets as a chosen nation progressed, and its long-duration welcome offers gave it the second-highest share of voice in the World Cup set off just three activations. Betfair's Golden Boot offer credited £1 per goal a selected player scored. These are the campaigns that create sustained engagement across a tournament rather than a single deposit spike, and they are the pattern to watch as the tournament proper arrives.

---

## 5. The experience layer

Promotion is the visible half of the contest. Journey experience is the half that does not appear on a media plan, and it is where the duty bites hardest, because acquisition bought at a higher cost of acquisition only pays back if the player stays.

Jurnii UX scores operators across four commercially weighted dimensions: journey, usability, performance, and perception. Across the UK set, portfolio journey scores cluster in the 70s, and the spread is not correlated with brand size. Ladbrokes and Betway both score 73 on overall journey; Betway sits 7 points behind bet365's 80. In a detailed competitive benchmark of the William Hill experience against four rivals, the weakest touchpoints were consistent across brands: casino play, getting help, and homepage discovery, alongside performance debt severe enough to register Time to Interactive in the 14 to 22 second range on estates carrying hundreds of open findings.

The recurring friction points repeat across almost every audited operator: no header search or filtering in the sportsbook and casino lobbies, promotional terms and wagering requirements buried behind a call to action, and Core Web Vitals debt from render-blocking scripts and unoptimised images. Registration and help journeys, by contrast, sit with clear headroom on most brands, and the market is already moving on them. Change-detection across the estate through the half-year logged a steady stream of registration and promotional-transparency improvements: William Hill rebuilt its registration into a single-field-per-step flow with a welcome-offer selection, lifting that journey score materially; Sky Bet, Betfair, and Paddy Power rolled out promotion-progress indicators and filterable promotion hubs on a shared platform; bet365 added a homepage player-markets widget; Paddy Power launched a community betting feed.

The commercial point is that none of this is visible in a promotional dashboard, and all of it decides whether a boosted, hard-won first deposit becomes a retained player or a one-session visitor. In a market where the highest-value players hold five accounts and defect on the first poor experience, that conversion is the whole game, and it is the least-instrumented part of most operators' commercial view.

---

## 6. Corporate and competitive landscape

The duty is not only reshaping promotion and experience. It is reshaping the operator set itself, and consolidation is live rather than anticipated.

**Consolidation and M&A.** The clearest signal is an active £225m bid for Evoke, at 50p per share, with a UK Takeover Panel deadline in June 2026. If completed, it would fold William Hill, 888, and Mr Green into an existing six-brand estate that already spans Jackpotjoy, Virgin Games, Monopoly Casino, Rainbow Riches Casino, Bally Bet, and Double Bubble Bingo. That acquirer reported UK online revenue up 10.5% in Q1 2026, active players up 7%, and April up a further 11.5%, all while carrying £1.27bn of adjusted net debt and reaffirming 2026 EBITDA guidance of £359m after absorbing a £95m UK tax impact. The UK is 64% of its group revenue. Whether or not the deal closes, the market is concentrating, and concentration rewards the operators who can prove their commercial position with evidence rather than assert it with instinct.

**Private versus listed exposure.** The duty's uneven bite is a competitive variable. Betfred, the largest privately-owned UK bookmaker, reported 99% online year-on-year growth and appointed a new media agency in January 2026 for accelerated growth, but as a UK-concentrated private operator it absorbs the 40% duty with no international offset. Betway's parent reported 71% European revenue growth in Q3 2025 with the UK as primary driver, but faces the loss of front-of-shirt football visibility, ended in May 2025, which shifts the brand burden onto the product experience.

**Challenger capital.** The consolidation at the top is matched by fresh capital at the challenger end. Midnite closed a $35m Series C in January 2026, taking total equity funding above $75m alongside a $100m credit facility, on an explicit product-first thesis: win on experience quality rather than promotional volume. Its promotional profile fits the thesis and the market structure, high frequency at 11.4% of all UK events, but low intensity at 1.7% of voice.

**Regulatory tightening.** Beyond the duty, the promotional rulebook changed in January 2026, introducing mixed-product bans, wagering caps, and customer-targeting restrictions. Each operator is adapting differently, which makes the mechanics themselves a moving competitive surface, not a settled one.

**Adjacent competition.** The National Lottery operator crossed 51% digital sales for the first time in FY2025 on £8.1bn of total sales, with 12m digital players, and completed a £450m-plus digital transformation. Its private-operator competitors, bet365, Sky Bet, Paddy Power, and William Hill, compete for the same casual recreational spend with purpose-built engagement products. The recreational-spend overlap widens further during the World Cup.

---

## 7. Outlook: what to watch in H2 2026

The first duty-compressed half-year established the direction. The second half will test who has adapted to it.

**Precision replaces volume as the core discipline.** The operators who navigate the duty will be the ones tracking margin conceded rather than headline boost, and share of voice rather than event count. The market has already shown that the two most efficient books, one at the value-dense end and one at the precision end, achieve more voice or more margin protection than the highest-volume operator. Expect that gap to widen as budgets tighten further.

**The World Cup is the year's decisive commercial window.** The build-up showed most operators protecting margin behind bigger headlines. The tournament proper will reward the operators who shift from awareness to conversion: fixture-anchored boosting, results-contingent mechanics, and, critically, a first-bet and first-cashout journey clean enough to retain the casual registrants the tournament floods into the funnel. Watch the move from tournament-wide outrights to fixture-by-fixture boosts as the signal that awareness spend is converting to turnover.

**Experience becomes a board-level number.** With acquisition costing more under the duty, the payback depends on retention, and retention is decided in the journey. The operators who instrument experience, benchmarked continuously against the competitive set rather than reviewed against their own last version, will convert their higher-cost acquisition where others leak it.

**Consolidation continues.** The Evoke situation is one visible node in a concentrating market. Each combination raises the premium on defensible, evidence-based commercial positioning, both for the acquirer integrating an estate and for the operators competing against a larger combined set.

The market has changed the job description. The task is no longer to spend more or ship more. It is to spend and ship with precision, and precision requires continuous visibility into a market that now moves in days. The operators who build that visibility will extend their lead through the duty. The rest will wait to see what happens.

---

## Methodology and sources

This report synthesises Jurnii's proprietary UK intelligence for the February to June 2026 window. Promotional figures are drawn from Jurnii 360, which tracked 13,673 promotional events across 21 UK brands in the 60-day core window, with a longer 15-week boost trajectory from 4 February. Share of Promotional Voice is an intensity-weighted measure accounting for boost richness and time live. Margin conceded is the probability handed to the player, calculated as the difference between the implied probabilities of the previous and boosted odds, in percentage points. Efficiency is boost percentage divided by margin conceded. Experience figures are drawn from Jurnii UX, which scores operators across four commercially weighted dimensions. Corporate figures are drawn from public operator results and disclosures within the window. Underlying artifacts are held in the `united-kingdom/` directory of this repository. A small number of source-to-source figure differences were resolved conservatively; readers should reconcile against primary operator disclosures before external citation.

*Jurnii is the commercial intelligence layer for iGaming operators. It automates UX benchmarking and competitor proposition tracking at scale, turning manual research, subjective opinion, and reactive analytics into structured, near-real-time intelligence. Compete on Experience. Win on Intelligence.*
