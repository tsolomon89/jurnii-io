---
type: Market Report
title: The Brazil iGaming Market Report, H1 2026
subtitle: Scale, shared infrastructure, and the experience contest in the first full year of regulation
region: Brazil (BR)
author: Jurnii Intelligence
date: 2026-08-03
tagline: Where UX Meets Commercial Strategy
evidence_window: Q1 to Q2 2026
data_basis: Jurnii UX Brazil journey benchmarks (400+ data points/brand) · Jurnii competitive feature audits · public market and regulatory disclosures
---

# The Brazil iGaming Market Report, H1 2026

*Scale, shared infrastructure, and the experience contest in the first full year of regulation.*

---

## Executive summary

Brazil is the largest new regulated iGaming market in the world, and 2026 is its first full year operating under the licensed framework. The market that has emerged is enormous, fragmented, and structurally unusual: 17.7 million bettors, more than 78 licensed operators, a top five holding under half of all volume, and a competitive set running on a small number of shared engines. In that environment, the sportsbook has stopped being the differentiator, and the experience on top of it has become the contest.

Six findings define the half-year.

1. **The market is large and fragmented.** 17.7 million unique bettors were recorded in the first half of 2025. Over 78 licensed operators now compete, and the top five hold roughly 47% of volume. Betano is the single largest at around 27% share. The remaining majority of the market is contested daily by everyone.
2. **The infrastructure is shared, so the engine is not the moat.** A large part of the licensed set runs on common B2B cores. One provider powers the sportsbook for multiple direct competitors, and a global group has deployed its proprietary engine into the market at a stated cost above $350m. Differentiation has moved to interface, journey, and friction.
3. **Experience does not track scale.** On Jurnii UX, the scale leader sits mid-table and a globally proven engine sits below three domestic-facing brands. The 11-point spread across the top of the market is a journey spread, not a technology one.
4. **Regulation put the hardest friction at the highest-intent moment.** Post-regulation KYC lands at the first deposit. Operators' answers diverge sharply, from single-screen registration to a three-step flow plus mandatory facial recognition, and the cleaner first-deposit journey wins the deposit in a market where every player holds several accounts.
5. **The World Cup is the decisive acquisition window, and it is shared.** Exclusive tournament coverage on a single streaming platform carries 104 matches and set a record of 5.6 million concurrent viewers. Three of the largest operators sponsor the same broadcast. The asset is common; the execution is not.
6. **Margin is compressing before the market has matured.** GGR tax is rising on a published schedule and a separate deposit-tax mechanism has advanced through the Senate, while advertising restrictions tighten precisely as the biggest brand-building window arrives.

The through-line mirrors the mature markets, arriving earlier and faster. When product cannot differentiate, experience must, and in Brazil the experience is where the next decade of share will be decided.

---

## 1. Market context: the largest regulated launch, at speed

The Brazilian regulated market arrived faster than most models predicted. The headline scale is 17.7 million unique bettors in the first half of 2025, a base that multi-homes by default: the average bettor holds three to five active accounts and decides where to deposit in the moment, on the offer and the experience in front of them. That behaviour, familiar from the UK and the US, is the defining condition of the market. Players in Brazil do not churn loudly. They reduce wallet share silently, across several apps at once.

The competitive set is unusually crowded. More than 78 licensed operators are active, and the top five hold only around 47% of volume. That fragmentation means the majority of the market sits outside the leaders and is contested continuously. Betano is the scale leader at roughly 27% share, ahead of a long tail of domestic-facing and international brands.

Two structural conditions shape every commercial decision. The first is shared infrastructure. A large share of the licensed set runs on the same B2B cores. One sportsbook provider powers multiple direct competitors, which means the odds engine, the live product, and the core betting infrastructure are common across brands. The second is margin pressure arriving early. GGR tax stands in the 12 to 13% range in 2026 and is scheduled to rise in subsequent years, and a separate deposit-tax mechanism, CIDE-Bets, has advanced through the Senate. As a single-market operator, a Brazilian pure-play has no geographic diversification to absorb that compression, which makes promotional efficiency and the experience that converts it a commercial necessity rather than a preference.

There is one condition with no equivalent in the mature markets: channelisation. The regulated market captures only around half of total activity; a large illegal market still competes for the same players. In that environment, experience quality is not only how licensed operators win share from each other. It is how the regulated market keeps players inside the regulated market at all, which reframes experience investment as market development, not just marketing.

---

## 2. Competitive structure and the experience benchmark

If the shared sportsbook engine decided outcomes, operators running the same core would converge on experience. They do not. Jurnii UX evaluates the licensed Brazilian set across four commercially weighted dimensions, usability, perception, journey, and performance, and 400-plus data points per brand, rolled into a single benchmarked score. The order of the market on experience is not the order of the market on scale.

| Brand | Jurnii UX score | Signal |
|---|---|---|
| Novibet | 74 | Top of the licensed set, highest journey scores |
| Esportes da Sorte | 73 | Strong UX foundation, close behind |
| EstrelaBet | 71 | Consistent across surfaces, registration edge |
| Betano | 67 | Scale leader, mid-table on experience |
| Betnacional | 65 | Global engine deploying, improving |
| Bet365 | 64 | Late entrant, global template ported |
| KTO | 63 | Shared-engine sportsbook, CX-invested |

The most important line in the table is that the scale leader sits mid-table on experience. Betano commands roughly 27% of the market and scores 67 on the journey; Novibet leads the experience benchmark at 74 with a fraction of that share. A globally proven engine at Betnacional scores 65, below three domestic-facing brands. The engine is not the moat. The journey is, and the score gap opens where the journeys are hardest: casino discovery, the deposit flow, registration, and getting help.

Journey-level benchmarking sharpens the picture. In a June 2026 assessment of a six-brand cohort across eleven touchpoints, overall journey scores ran from 54 to 65, and the divergence was concentrated in exactly the conversion-critical steps. Depositing scored in the 40s across almost the entire cohort. Playing casino games and using bonuses and promotions were the weakest steps for several brands. Entry and homepage, by contrast, scored in the high 80s. The Brazilian market has built strong front doors and left the highest-value rooms, deposits and casino play, under-finished.

---

## 3. The experience layer in detail

The competitive feature audit shows where the shared-infrastructure market actually separates, and it is at the surfaces regulation does not standardise.

**Onboarding and the first deposit.** Brazil's regulated KYC lands at the first deposit, the single highest-intent moment in the funnel, and the market's answers diverge more here than anywhere else. Effective steps to activation run from a single-screen form at one operator to a three-step flow plus mandatory facial recognition at another, the highest onboarding friction in the cohort, imposed at the exact moment a new player is deciding whether to continue. The winning pattern surfaces the CPF at the very start and pre-fills name, date of birth, and address from it, cutting manual entry to almost nothing. The regulatory posture also varies: one operator makes loss and login limits mandatory fields inside registration, the strongest responsible-gambling stance in the cohort, while another carries no in-flow responsible-gambling presence at all.

**The cashier and the depth of PIX.** Payment breadth at the deposit moment is a live competitive surface, and the spread is stark. In one competitive audit, payment-method counts ranged from a single PIX entry point at some operators to eight bank-specific PIX variants and quick-select chips at bet365. In a market where the national rail is PIX, the depth of a PIX implementation is not a back-office detail. A single-method cashier is the thinnest deposit selection in the cohort, and in a multi-homing market a stalled deposit is not a retry. It is the next tab. The deposit journey scores across the market, clustered in the 40s and 50s, confirm that the cashier is the market's most under-built high-value surface.

**Withdrawals and recovery paths.** The audit surfaced a specific and expensive defect pattern: a withdrawal flow gated behind a mandatory biometric check with no documented recovery path, where a tested failure locked the user out of the form entirely. Compliance-driven verification is unavoidable in the Brazilian market. Verification with no recovery route is a design failure at the moment a player is trying to take money out, which is the moment trust is most fragile.

**Casino discovery.** Casino coverage is the widest experience gap in the market. Feature coverage on casino ran from 100% at Betano to under 40% at some rivals, with the common failures being lobbies that ship without provider, RTP, volatility, or theme filters, and without demo play. In a market cross-selling sports bettors into casino, discovery is the conversion mechanism, and most operators are shipping it thin.

The recurring theme across the experience layer is consistent with the benchmark scores. The front door is strong across the market. The deposit, the withdrawal, the casino lobby, and the help journey, the surfaces that convert acquisition into retained value, are where the licensed operators are separating, and where most of them are leaving value on the table.

---

## 4. Acquisition and the sponsorship landscape

Brazil hosts the most concentrated acquisition window in its short regulated history, and it is built around a single broadcast. Exclusive tournament coverage on the CazéTV streaming platform carries 104 World Cup matches, and the platform set a record of 5.6 million concurrent viewers during a Club World Cup fixture. The sponsorship stack around it is dense and overlapping: three of the largest operators, KTO, Betnacional, and Bet365, sponsor the CazéTV broadcast; Betnacional holds the primary World Cup slot; Bet365 also sponsors Paulistão; and Betano holds FIFA Club World Cup. The sponsorship asset is shared, which means the execution around it is what differentiates.

This is where the multi-homing market punishes awareness that does not convert. A 5.6-million-viewer moment is brand exposure, not retention. The Brazilian bettor will see several operators' World Cup creative before deciding where to deposit, and the sharpest, best-timed offer, landing on the cleanest first-deposit journey, captures the deposit and the months of value behind it. Awareness bought at tournament prices and squandered on a friction-heavy onboarding flow is a marketing cost line, not a marketing return.

The regulatory backdrop raises the stakes. Senate-approved advertising restrictions, including a watershed and a prohibition on live-broadcast betting advertising, are advancing toward implementation. Their effect is to increase the marginal cost of brand-building precisely as the biggest brand-building window of the decade arrives. As broadcast tightens, the operators who win will be the ones whose product and promotional execution compensate for it. That is a structural shift from media buying toward experience execution, and it is happening in real time.

Localisation is the domestic operators' current advantage, and it is time-limited. The brands leading the experience benchmark lead in part on hyper-local execution: Portuguese-language support, PIX-first payments that pre-fill from the national ID, and Brazilian football partnerships. That advantage is real today and eroding steadily, as the global entrants close the gaps. The payment audit already shows how quickly the ground can move, with a global brand shipping the deepest PIX implementation in the cohort. Localisation is a lead measured in quarters, not a permanent moat, and the only way to defend a lead you cannot see eroding is to benchmark it continuously against the set that is closing it.

---

## 5. Corporate and capital landscape

The Brazilian market is a magnet for global capital, and the corporate posture of the largest players tells the strategic story.

**The patient-capital land grab.** The clearest expression is the deployment of a proprietary global engine into a domestic brand at scale. A global group has committed over $350m to its Brazil position, is absorbing annual losses reported above $90m, and has set an explicit ambition to move from around 5% share to a podium, top-three, position. That is a patient-capital strategy: accept near-term losses to buy long-term share in the largest new market in the industry. The commercial risk in that thesis is that it rests on the proprietary engine delivering product superiority, and the experience benchmark shows the brand at 65, below three domestic rivals. Global technology needs local validation, and the gap to close is a journey gap, not an engine one.

**Scale versus experience.** Betano's position, roughly 27% share at a mid-table experience score of 67, illustrates the market's central tension. Scale was won in the acquisition phase, largely on brand and promotional spend. Retention in the multi-homing phase is a journey question, and the scale leader does not automatically lead on the journey. The operators closing on it are the domestic-facing brands leading the experience benchmark.

**The shared-engine challengers.** Operators running third-party sportsbook cores, such as KTO on a major B2B provider, face the shared-infrastructure problem in its purest form. When the engine is common, the product layer built on top is the only structural moat, which makes UX and promotional execution the entire competitive lever. KTO's Reclame Aqui CX nomination signals internal awareness of this; the experience benchmark, at 63, signals the distance still to travel.

**Capital concentrating globally.** The corporate backdrop is one of tier-one gaming capital consolidating on Wall Street. Flutter Entertainment completed the cancellation of its London Stock Exchange listing on 3 August 2026, leaving the NYSE as its sole venue. The move reflects where growth capital and institutional weight now concentrate in global sports betting, and it sits behind the willingness of the largest groups to fund multi-year, loss-absorbing positions in Brazil. Capital efficiency at the corporate level and promotional and experience efficiency on the ground are the same discipline expressed at two scales.

---

## 6. Outlook: what to watch in H2 2026

The first full regulated year established the shape of the market. The second half will test who has adapted to its unusual structure.

**Retention becomes the battleground.** The acquisition phase, driven by upfront bonuses and broadcast spend, is giving way to a retention phase. As bonus impact fades and advertising tightens, the brands that keep players engaged longer will gain ground, and engagement in a multi-homing market is a journey question before it is a promotional one. The operator that wins the first cashout, not just the first deposit, keeps the player.

**The World Cup converts, or it does not.** The tournament is the year's decisive commercial window, and it will reward the operators who move from awareness to conversion. The signal to watch is the shift from tournament-wide outrights to fixture-by-fixture activation, and, critically, whether the casual registrants the tournament floods into the funnel meet a first-deposit and first-cashout journey clean enough to retain them.

**Channelisation sets the ceiling.** With roughly half of activity still outside the regulated market, the growth ceiling of the licensed market is defined partly by how good the regulated experience is. Better journeys do not only move share between licensed operators. They keep players regulated, which makes experience quality a market-development lever, not just a competitive one.

**Localisation advantage expires.** The domestic brands' lead on Portuguese support, PIX depth, and local partnerships is real and closing. The global entrants have the capital and the intent to close it. The operators who defend the lead will be the ones measuring it continuously against the set that is eroding it.

**Margin pressure forces efficiency.** With GGR tax rising and a deposit tax advancing, every point of promotional spend has to be justified against return. Promotional efficiency, and the experience that converts it, moves from a metric to a survival condition for single-market operators.

The Brazilian market arrived at the same destination as the mature markets, earlier and faster. Product cannot differentiate, because the engine is shared. Scale did not settle the market, because retention is a journey question. What is left is the experience, and the operators who treat it as a measurable commercial system, benchmarked continuously against the competitive set, are the ones who will convert the largest new market in the industry into durable share.

---

## Methodology and sources

This report synthesises Jurnii's Brazil intelligence for the Q1 to Q2 2026 window. Experience figures are drawn from Jurnii UX, which scores operators across four commercially weighted dimensions using 400-plus data points per brand, and from Jurnii competitive feature audits of the licensed set. Market-size, share, tax, channelisation, sponsorship, and corporate figures are drawn from public market and regulatory disclosures within the window. Tax figures vary across sources: published GGR rates for 2026 sit in the 12 to 13% range with rises scheduled thereafter, and a separate CIDE-Bets deposit-tax mechanism has advanced through the Senate; readers should reconcile against primary regulatory sources before external citation. Underlying artifacts are held in the `brazil-latam/` and `cross-market/` directories of this repository.

*Jurnii is the commercial intelligence layer for iGaming operators. It automates UX benchmarking and competitor proposition tracking at scale, turning manual research, subjective opinion, and reactive analytics into structured, near-real-time intelligence. Compete on Experience. Win on Intelligence.*
